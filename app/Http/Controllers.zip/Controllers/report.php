<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\orderedProducts;
use App\Models\order;
use App\Models\delivery1;
use App\Models\delivery2;
use Auth;

class report extends Controller
{
    public function kdReportOrderAccepted()
    {
        # code..
        $order = order::join('key_distros','orders.KD_id','key_distros.id')->where('KD_id',Auth::id())->get();
        return view('kd.reportOrderAccepted',compact('order'));
    }
    public function kdReportHandover()
    {
        #code ...
        $handover = delivery1::join('users','users.id','=','delivery1s.rom_id')
        ->join('roms','roms.user_id','=','delivery1s.rom_id')
        ->leftjoin('orders','delivery1s.order_id','=','orders.id')
        ->where('delivery1s.kd_id', Auth::id())
        ->get();
        return view('kd.reportHandover', compact('handover'));
    }
    public function romReportHanoveraccepted()
    {
        # code...
        $handover = delivery1::join('users','users.id','=','delivery1s.kd_id')
        ->join('key_distros','key_distros.user_id','=','delivery1s.kd_id')
        ->leftjoin('orders','delivery1s.order_id','=','orders.id')
        ->where('delivery1s.rom_id', Auth::id())
        ->get();
        return view('rom.reportHandoverAccepted',compact('handover'));
    }
    public function romReportHanoverdelivered()
    {
        $handover = delivery2::join('users','users.id','=','delivery2s.rsp_id')
        ->join('rsps','rsps.user_id','=','delivery2s.rsp_id')
        ->leftjoin('orders','delivery2s.order_id','=','orders.id')
        ->where('delivery2s.rom_id', Auth::id())
        ->get();
        return view('rom.reportHandoverDelivered',compact('handover'));
    }
    public function adminPaymentReport()
    {
        #code ...
        $paymentReport = order::join('users','users.id','=','orders.client_id')
        ->join('clients','clients.user_id','=','orders.client_id')
        ->get(['orders.id','orders.paymentStatus','orders.created_at','users.firstName','users.middleName','users.lastName','orders.KD_id']);
        return view('admin.adminPaymentReport',compact('paymentReport'));
    }
    public function adminLastmileReport()
    {
         $LastMileReport = order::join('users','users.id','=','orders.client_id')
        ->join('clients','clients.user_id','=','orders.client_id')
        ->join('delivery3s','delivery3s.order_id','orders.id')
        ->get(['orders.id','orders.deliveryStatus','orders.created_at','delivery3s.createdAt','users.firstName','users.middleName','users.lastName','delivery3s.rsp_id']);
        return view('admin.adminLastMileReport',compact('LastMileReport'));
    }
    public function adminKDOrderConformationReport()
    {
        $orderConformation = order::join('users','users.id','=','orders.KD_id')
        ->join('key_distros','key_distros.user_id','=','orders.KD_id')
        ->get(['orders.id','orders.confirmStatus','orders.created_at','users.firstName','users.middleName','users.lastName','orders.client_id']);
        return view('admin.adminKDOrderConformationReport',compact('orderConformation'));
    }
}
