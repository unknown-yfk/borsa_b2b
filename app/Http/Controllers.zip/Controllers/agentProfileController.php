<?php

namespace App\Http\Controllers;

use App\Models\agent;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\businessType;
use App\Models\idType;
use App\Models\order;
use RealRashid\SweetAlert\Facades\Alert;
use Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Hash;
// use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Builder;
use App;

class agentProfileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $confirm = order::where('confirmStatus','confirmed')->where('createdBy', Auth::id())->count();
        $unconfirm = order::where('confirmStatus','unconfirmed')->where('createdBy', Auth::id())->count();
        $delieverd = order::where('deliveryStatus','Delivered')->where('createdBy', Auth::id())->count();
        return view('dashboard.agentDashboard',compact('confirm','unconfirm','delieverd'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $businessType = businessType::all();
        $idType= idType::all();

        return view('agent.create',compact('businessType','idType'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $request->validate([
            'address' =>'required',
            'mobile' =>'required|digits:10',
            'id_path'=>'required|image|mimes:jpg,png,jpeg|max:5048',
            'idType' =>'required',
            'ID_number' =>'required',
            'ID_issue_date' =>'required|date',
            'ID_expiry_date' =>'required|date',
            'businessName' =>'required',
            'businessType' =>'required',
            'businessAddress' =>'required',
            'licenceFilePath'=>'required|image|mimes:jpg,png,jpeg|max:5048',
            'licenceNumber' =>'required',
            'issueDate' =>'required|date',
            'expiryDate' =>'required|date',
            'tinNumber' =>'required',
            'businessEstablishmentYear' =>'required'
        ]);

       $image_id  = $request->id_path;
       $imagename = time() . '.' . $image_id->getClientOriginalExtension();
       $request->id_path->move('assets/gov_img',$imagename);
       $image_licence = $request->licenceFilePath;
       $imagenameL = time() . '.' . $image_licence->getClientOriginalExtension();
       $request->licenceFilePath->move('assets/licences_img',$imagenameL);
       $user = user::find(auth()->user()->id);
       $user_pro  = $request->profilePicture;
       $user_proName = time() . '.' . $user_pro->getClientOriginalExtension();
       $request->profilePicture->move('assets/users_img',$user_proName);
       $user->userPhoto = $user_proName;
       $user->save();
        $agent = agent::create([
            'user_id'=>auth()->user()->id,
            'address'=> $request->address,
            'mobile'=>$request->mobile,
            'id_file_path'=> $imagename,
            'ID_type' => $request->idType,
            'ID_number'=> $request->ID_number,
            'ID_issue_date'=> $request->ID_issue_date,
            'ID_expiry_date'=> $request->ID_expiry_date,
            'businessName'=>$request->businessName,
            'businessType'=> $request->businessType,
            'businessAddress'=>$request->businessAddress,
            'licenceFilePath'=> $imagenameL,
            'licenceNumber'=>$request->licenceNumber,
            'issueDate'=> $request->issueDate,
            'expiryDate'=> $request->expiryDate,
            'tinNumber'=> $request->tinNumber,
            'businessEstablishmentYear'=> $request->businessEstablishmentYear,

        ]);
        Alert::toast('Successfully Added!', 'success');
        return redirect('/agentDashboard');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\agent  $agent
     * @return \Illuminate\Http\Response
     */
    public function show(agent $agentProfile)
    {
        $agentProfile = agent::join('users','users.id','=','agents.user_id')
        ->where('agents.user_id',auth()->user()->id)->get();
        return view('agent.showProfile',compact('agentProfile'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\agent  $agent
     * @return \Illuminate\Http\Response
     */
    public function edit(agent $agent)
    {
        $agentProfile = agent::join('users','users.id','=','agents.user_id')
        ->where('agents.user_id',auth()->user()->id)->get();
        $businessType = businessType::all();
        $idType= idType::all();
        return view('agent.profileUpdate',compact('agentProfile','businessType','idType'));;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\agent  $agent
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, agent $agent)
    {
        $request->validate([
            'firstName' => ['required', 'string', 'max:255'],
            'middleName' => ['required', 'string', 'max:255'],
            'lastName' => ['required', 'string', 'max:255'],
            'userName' => ['required', 'string', 'max:255'],
            'email' => [ 'string', 'email', 'max:255'],
            'address' =>'required',
            'mobile' =>'required',
            'idType' =>'required',
            'ID_number' =>'required',
            'ID_issue_date' =>'required|date',
            'ID_expiry_date' =>'required|date',
            'businessName' =>'required',
            'businessType' =>'required',
            'businessAddress' =>'required',
            'licenceNumber' =>'required',
            'issueDate' =>'required|date',
            'expiryDate' =>'required|date',
            'tinNumber' =>'required',
            'businessEstablishmentYear' =>'required'
        ]);

        if($request->id_path)
        {
            $image_id  = $request->id_path;
            $imagename = time() . '.' . $image_id->getClientOriginalExtension();
            $request->id_path->move('assets/gov_img',$imagename);
             $kdProfile = agent::join('users','users.id','=','agents.user_id')
        ->where('agents.user_id',auth()->user()->id)->update([
            'id_file_path' => $imagename,
        ]);

        }
        else{
            $kdProfile = agent::join('users','users.id','=','agents.user_id')
        ->where('agents.user_id',auth()->user()->id)->update([
            'id_file_path' => $request->id_path_recover,
        ]);
        }

        if($request->licenceFilePath)
        {
            $image_licence = $request->licenceFilePath;
            $imagenameL = time() . '.' . $image_licence->getClientOriginalExtension();
            $request->licenceFilePath->move('assets/licences_img',$imagenameL);
             $kdProfile = agent::join('users','users.id','=','agents.user_id')
        ->where('agents.user_id',auth()->user()->id)->update([
              'licenceFilePath'=>$imagenameL,
        ]);
        }
        else{
            $kdProfile = agent::join('users','users.id','=','agents.user_id')
        ->where('agents.user_id',auth()->user()->id)->update([
            'licenceFilePath' => $request->licenceFilePath_recover,
        ]);
        }

        if($request->userPhoto)
        {
            $user_pro  = $request->userPhoto;
            $user_proName = time() . '.' . $user_pro->getClientOriginalExtension();
            $request->userPhoto->move('assets/user_img',$user_proName);
            $kdProfile = agent::join('users','users.id','=','agents.user_id')
        ->where('agents.user_id',auth()->user()->id)->update([
             'userPhoto'=> $user_proName,
        ]);
        }
        else{
            $kdProfile = agent::join('users','users.id','=','agents.user_id')
        ->where('agents.user_id',auth()->user()->id)->update([
             'userPhoto'=> $request->userPhoto_recover,
        ]);
        }
        $agentProfile = agent::join('users','users.id','=','agents.user_id')
        ->where('agents.user_id',auth()->user()->id)->update([
            'firstName'=> $request->firstName,
            'middleName'=>$request->middleName,
            'lastName'=> $request->lastName,
            'userName'=>$request->userName,
            'email'=> $request->email,
            'address'=> $request->address,
            'mobile'=>$request->mobile,
            'ID_type'=>$request->idType,
            'ID_number'=> $request->ID_number,
            'ID_issue_date'=> $request->ID_issue_date,
            'ID_expiry_date'=> $request->ID_expiry_date,
            'businessName'=>$request->businessName,
            'businessType'=> $request->businessType,
            'businessAddress'=>$request->businessAddress,
            'licenceNumber'=>$request->licenceNumber,
            'issueDate'=> $request->issueDate,
            'expiryDate'=> $request->expiryDate,
            'tinNumber'=> $request->tinNumber,
            'businessEstablishmentYear'=> $request->businessEstablishmentYear,
        ]);
        Alert::toast('Successfully Updated!', 'success');
        return redirect()->route('agent.dashboard');

    }
    public function change_password()
    {
        return view('agent.changePassword');
    }
    public function update_password(Request $request)
    {
        if (App::environment('demo')) {
            return redirect()->back()->with('error', 'Action not allowed in demo.');
        }
        $user = Auth::user();
        $request->validate([
            'password' => 'required|confirmed',
            'password_confirmation' => 'required',
        ]);
        if (!Hash::check($request->current_password, $user->password)) {
             Alert::toast('Invalid Password!', 'warning');
            return redirect()->route('agent_change_password');
        }
        $credentials = [
            'password' => Hash::make($request->password),
        ];
        $user->update($credentials);

        Alert::toast('Password Changed Successfuly!', 'success');
         return redirect()->route('agent.dashboard');
    }
    public function destroy(agent $agent)
    {
        //
    }
}
