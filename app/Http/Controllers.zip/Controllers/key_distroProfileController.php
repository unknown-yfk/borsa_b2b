<?php

namespace App\Http\Controllers;

use App\Models\key_distro;
use App\Models\user;
use Illuminate\Http\Request;
use App\Models\businessType;
use Illuminate\Support\Facades\Hash;
use App\Models\idType;
use Auth;
use App;


use RealRashid\SweetAlert\Facades\Alert;

class key_distroProfileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $businessType=businessType::all();
        $idType= idType::all();
        $today = date('Y-m-d H:i:s');
        return view('KD.create',compact('businessType','idType','today'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

       $key_distro = $request->validate([
            // 'address' =>'required',
            'mobile' =>'required|digits:10',
            'id_path'=>'required|image|mimes:jpg,png,jpeg|max:5048',
            'idType' =>'required',
            'ID_number' =>'required',
            'ID_issue_date' =>'required|date',
            'ID_expiry_date' =>'required|date',
            'businessName' =>'required',
            'businessType' =>'required',
            'businessAddress' =>'required',
            'licenceFilePath'=>'required|image|mimes:jpg,png,jpeg|max:5048',
            'licenceNumber' =>'required',
            'issueDate' =>'required|date',
            'expiryDate' =>'required|date',
            'tinNumber' =>'required',
            'businessEstablishmentYear' =>'required',
            'profilePicture' =>'image|mimes:jpg,png,jpeg|max:5048',
        ]);

       // $users = user::where('id', auth()->user()->id)->get('users.firstName','users.lastName');
       // return $user;
       $image_id  = $request->id_path;
       $imagename = time() . '.' . $image_id->getClientOriginalExtension();
       $request->id_path->move('assets/gov_img',$imagename);

       $image_licence = $request->licenceFilePath;
       $imagenameL = time() . '.' . $image_licence->getClientOriginalExtension();
       $request->licenceFilePath->move('assets/licences_img',$imagenameL);

       $user = user::find(auth()->user()->id);
       $user_pro  = $request->profilePicture;
       $user_proName = time() . '.' . $user_pro->getClientOriginalExtension();
       $request->profilePicture->move('assets/users_img',$user_proName);
       $user->userPhoto = $user_proName;
       $user->save();
        $request = key_distro::create([
            'user_id'=>auth()->user()->id,
            'address'=> $request->address,
            'mobile'=>$request->mobile,
            'id_file_path'=> $imagename,
            'ID_type'=>$request->idType,
            'ID_number'=> $request->ID_number,
            'ID_issue_date'=> $request->ID_issue_date,
            'ID_expiry_date'=> $request->ID_expiry_date,
            'businessName'=>$request->businessName,
            'businessType'=> $request->businessType,
            'businessAddress'=>$request->businessAddress,
            'licenceFilePath'=> $imagenameL,
            'licenceNumber'=>$request->licenceNumber,
            'issueDate'=> $request->issueDate,
            'expiryDate'=> $request->expiryDate,
            'tinNumber'=> $request->tinNumber,
            'businessEstablishmentYear'=> $request->businessEstablishmentYear,
            'latitude'=> $request->lat,
            'longtude'=> $request->lng,

        ]);

     Alert::toast('Successfully Completed!', 'success');
        return redirect('/key_distroDashboard');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\key_distro  $key_distro
     * @return \Illuminate\Http\Response
     */
    public function show(key_distro $kdProfile)
    {
        $kdProfile=key_distro::join('users','users.id','=','key_distros.user_id')
        ->where('key_distros.user_id',auth()->user()->id)->get();
        return view('KD.showProfile',compact('kdProfile'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\key_distro  $key_distro
     * @return \Illuminate\Http\Response
     */
    public function edit(key_distro $key_distro)
    {
        $kdProfile = key_distro::join('users','users.id','=','key_distros.user_id')
        ->where('key_distros.user_id',auth()->user()->id)->get();
        $businessType = businessType::all();
        $idType= idType::all();

        return view('KD.profileUpdate',compact('kdProfile', 'businessType','idType'));


    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\key_distro  $key_distro
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, key_distro $key_distro)
    {
        $request->validate([
            'address' =>'required',
            'mobile' =>'required|digits:10',
            'id_path'=>'image|mimes:jpg,png,jpeg|max:5048',
            'idType' =>'required',
            'ID_number' =>'required',
            'ID_issue_date' =>'required|date',
            'ID_expiry_date' =>'required|date',
            'businessName' =>'required',
            'businessType' =>'required',
            'businessAddress' =>'required',
            'licenceFilePath'=>'image|mimes:jpg,png,jpeg|max:5048',
            'licenceNumber' =>'required',
            'issueDate' =>'required|date',
            'expiryDate' =>'required|date',
            'tinNumber' =>'required',
            'businessEstablishmentYear' =>'required',
            'userPhoto' =>'image|mimes:jpg,png,jpeg|max:5048',

        ]);
        if($request->id_path)
        {
            $image_id  = $request->id_path;
            $imagename = time() . '.' . $image_id->getClientOriginalExtension();
            $request->id_path->move('assets/gov_img',$imagename);
             $kdProfile = key_distro::join('users','users.id','=','key_distros.user_id')
        ->where('key_distros.user_id',auth()->user()->id)->update([
            'id_file_path' => $imagename,
        ]);

        }
        else{
            $kdProfile = key_distro::join('users','users.id','=','key_distros.user_id')
        ->where('key_distros.user_id',auth()->user()->id)->update([
            'id_file_path' => $request->id_path_recover,
        ]);
        }

        if($request->licenceFilePath)
        {
            $image_licence = $request->licenceFilePath;
            $imagenameL = time() . '.' . $image_licence->getClientOriginalExtension();
            $request->licenceFilePath->move('assets/licences_img',$imagenameL);
             $kdProfile = key_distro::join('users','users.id','=','key_distros.user_id')
        ->where('key_distros.user_id',auth()->user()->id)->update([
              'licenceFilePath'=>$imagenameL,
        ]);
        }
        else{
            $kdProfile = key_distro::join('users','users.id','=','key_distros.user_id')
        ->where('key_distros.user_id',auth()->user()->id)->update([
            'licenceFilePath' => $request->licenceFilePath_recover,
        ]);
        }

        if($request->userPhoto)
        {
            $user_pro  = $request->userPhoto;
            $user_proName = time() . '.' . $user_pro->getClientOriginalExtension();
            $request->userPhoto->move('assets/users_img',$user_proName);
            $kdProfile = key_distro::join('users','users.id','=','key_distros.user_id')
        ->where('key_distros.user_id',auth()->user()->id)->update([
             'userPhoto'=> $user_proName,
        ]);
        }
        else{
            $kdProfile = key_distro::join('users','users.id','=','key_distros.user_id')
        ->where('key_distros.user_id',auth()->user()->id)->update([
             'userPhoto'=> $request->userPhoto_recover,
        ]);
        }

        $kdProfile = key_distro::join('users','users.id','=','key_distros.user_id')
        ->where('key_distros.user_id',auth()->user()->id)->update([
            'firstName'=> $request->firstName,
            'middleName'=>$request->middleName,
            'lastName'=> $request->lastName,
            'userName'=>$request->userName,
            'email'=> $request->email,
            'address'=> $request->address,
            'mobile'=>$request->mobile,
            // 'id_file_path' => $imagename,
            'ID_type'=>$request->idType,
            'ID_number'=> $request->ID_number,
            'ID_issue_date'=> $request->ID_issue_date,
            'ID_expiry_date'=> $request->ID_expiry_date,
            'businessName'=>$request->businessName,
            'businessType'=> $request->businessType,
            'businessAddress'=>$request->businessAddress,
            'licenceNumber'=>$request->licenceNumber,
            // 'licenceFilePath'=>$imagenameL,
            'issueDate'=> $request->issueDate,
            'expiryDate'=> $request->expiryDate,
            'tinNumber'=> $request->tinNumber,
            'businessEstablishmentYear'=> $request->businessEstablishmentYear,
            'latitude'=> $request->lat,
            'longtude'=> $request->lng,
            // 'userPhoto'=> $user_proName,
        ]);
        Alert::toast('Successfully Updated!', 'success');
        return redirect('/key_distroDashboard');

    }
     public function change_password()
    {
        return view('KD.changePassword');
    }
    public function update_password(Request $request)
    {
        if (App::environment('demo')) {
            return redirect()->back()->with('error', 'Action not allowed in demo.');
        }
        $user = Auth::user();
        $request->validate([
            'password' => 'required|confirmed',
            'password_confirmation' => 'required',
        ]);
        if (!Hash::check($request->current_password, $user->password)) {
             Alert::toast('Invalid Password!', 'warning');
            return redirect()->route('kd_change_password');
        }
        $credentials = [
            'password' => Hash::make($request->password),
        ];
        $user->update($credentials);

        Alert::toast('Password Changed Successfuly!', 'success');
         return redirect('/key_distroDashboard');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\key_distro  $key_distro
     * @return \Illuminate\Http\Response
     */
    public function destroy(key_distro $key_distro)
    {
        //
    }
}
