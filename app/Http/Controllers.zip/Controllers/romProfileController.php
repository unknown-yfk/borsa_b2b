<?php

namespace App\Http\Controllers;

use App;
use Auth;
use App\Models\rom;
use App\Models\user;
use App\Models\delivery1;
use App\Models\delivery2;
use App\Models\idType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use RealRashid\SweetAlert\Facades\Alert;

class romProfileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(){
        $recivedDelivery = delivery1::where('rom_id',Auth::id())->count();
        $handoverd = delivery2::where('rom_id',Auth::id())->count();
        $activeDelivery = delivery1::where('rom_id',Auth::id())->where('confirmationStatus','unconfirmed')->count();
        return view('dashboard.romDashboard',compact('recivedDelivery','activeDelivery','handoverd'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $idType = idType::all();
        return view('ROM.create', compact('idType'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'address' =>'required',
            'mobile' =>'required|digits:10',
            'id_path'=>'required|image|mimes:jpg,png,jpeg|max:5048',
            'idType' =>'required',
            'ID_number' =>'required',
            'ID_issue_date' =>'required|date',
            'ID_expiry_date' =>'required|date',
            'profilePicture' => 'required|image|mimes:jpg,png,jpeg|max:5048'
        ]);

        $id_path = $request->id_path;
        $woredaPic = time() . '.' . $id_path->getClientOriginalExtension();
        $request->id_path->move('assets/gov_img',$woredaPic);
        $user = user::find(auth()->user()->id);
        $user_pro  = $request->profilePicture;
        $user_proName = time() . '.' . $user_pro->getClientOriginalExtension();
        $request->profilePicture->move('assets/users_img',$user_proName);
        $user->userPhoto = $user_proName;
        $user->save();
        $rom = rom::create([
            'user_id'=>auth()->user()->id,
            'address'=> $request->address,
            'mobile'=>$request->mobile,
            'id_filepath'=> $woredaPic,
            'ID_type'=>$request->idType,
            'ID_number'=> $request->ID_number,
            'ID_issue_date'=> $request->ID_issue_date,
            'ID_expiry_date'=> $request->ID_expiry_date,
            'latitude' => $request->lat,
            'longtude' => $request->lng,

        ]);

         Alert::toast('Successfully Completed!', 'success');
        return redirect('/romDashboard');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\rom  $rom
     * @return \Illuminate\Http\Response
     */
    public function show(rom $romProfile)
    {
        $romProfile=rom::join('users','users.id','=','roms.user_id')
        ->where('roms.user_id',auth()->user()->id)->get();
        return view('ROM.showProfile',compact('romProfile'));;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\rom  $rom
     * @return \Illuminate\Http\Response
     */
    public function edit(rom $rom)
    {
        $romProfile=rom::join('users','users.id','=','roms.user_id')
        ->where('roms.user_id',auth()->user()->id)->get();
         $idType = idType::all();
         return view('ROM.ProfileUpdate',compact('romProfile', 'idType'));;

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\rom  $rom
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, rom $rom)
    {

         if($request->id_path)
        {
            $image_id  = $request->id_path;
            $imagename = time() . '.' . $image_id->getClientOriginalExtension();
            $request->id_path->move('assets/gov_img',$imagename);
             $kdProfile = rom::join('users','users.id','=','roms.user_id')
        ->where('roms.user_id',auth()->user()->id)->update([
            'id_filepath' => $imagename,
        ]);

        }
        else{
            $kdProfile = rom::join('users','users.id','=','roms.user_id')
        ->where('roms.user_id',auth()->user()->id)->update([
            'id_filepath' => $request->id_path_recover,
        ]);
        }
        if($request->userPhoto)
        {
            $user_pro  = $request->userPhoto;
            $user_proName = time() . '.' . $user_pro->getClientOriginalExtension();
            $request->userPhoto->move('assets/user_img',$user_proName);
            $kdProfile = rom::join('users','users.id','=','roms.user_id')
        ->where('roms.user_id',auth()->user()->id)->update([
             'userPhoto'=> $user_proName,
        ]);
        }
        else{
            $kdProfile = rom::join('users','users.id','=','roms.user_id')
        ->where('roms.user_id',auth()->user()->id)->update([
             'userPhoto'=> $request->userPhoto_recover,
        ]);
        }
        $ROMProfile = rom::join('users','users.id','=','roms.user_id')
        ->where('roms.user_id',auth()->user()->id)->update([
            'firstName'=> $request->firstName,
            'middleName'=>$request->middleName,
            'lastName'=> $request->lastName,
            'userName'=>$request->userName,
            'email'=> $request->email,
            'address'=> $request->address,
            'mobile'=>$request->mobile,
            // 'id_filepath'=> $distro_id_image_name,
            'ID_type'=>$request->idType,
            'ID_number'=> $request->ID_number,
            'ID_issue_date'=> $request->ID_issue_date,
            'ID_expiry_date'=> $request->ID_expiry_date,
        ]);
          Alert::toast('Successfully updated!', 'success');
         return redirect('/romDashboard');
    }
    public function change_password()
    {
        return view('ROM.changePassword');
    }
    public function update_password(Request $request)
    {
        if (App::environment('demo')) {
            return redirect()->back()->with('error', 'Action not allowed in demo.');
        }
        $user = Auth::user();
        $request->validate([
            'password' => 'required|confirmed',
            'password_confirmation' => 'required',
        ]);
        if (!Hash::check($request->current_password, $user->password)) {
             Alert::toast('Invalid Password!', 'warning');
            return redirect()->route('rom_change_password');
        }
        $credentials = [
            'password' => Hash::make($request->password),
        ];
        $user->update($credentials);

        Alert::toast('Password Changed Successfuly!', 'success');
         return redirect('/romDashboard');
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\rom  $rom
     * @return \Illuminate\Http\Response
     */
    public function destroy(rom $rom)
    {
        //
    }
}
