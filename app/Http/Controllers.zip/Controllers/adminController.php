<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\client;
use App\Models\user;
use App\Models\key_distro;
use App\Models\businessType;
use App\Models\order;
use App\Models\idType;
use App\Models\ProductCatagory;
use App\Models\ProductType;
use App\Models\product;
use App\Models\orderedProducts;
use App\Models\undeliveredOrders;
use App\Models\delivery1Products;
use App\Models\undelivered1Products;
use Illuminate\Support\Facades\Hash;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Builder;


class adminController extends Controller
{

    public function index()
    {
        $client =client::count();
        $users =user::count();
        $kds =key_distro::count();
        $userList=user::get();
        $todaysOrders=order::where('createdDate',today())->count();
        $totalOrders =order::count();
        return view('dashboard.adminDashboard',compact('client','kds','users','todaysOrders','totalOrders'));
    }

    public function add_product(Request $request)
    {
        $key_distro = key_distro::join('users','users.id','=','key_distros.user_id')->get();
        $catagory = ProductCatagory::all();
        $productType= ProductType::all();
        return view('admin.addProducts',compact('catagory', 'productType', 'key_distro'));
    }
     public function store_product(Request $request)
    {
       $request->validate([
             'image'=>'required|image|mimes:jpg,png,jpeg|max:5048',
             'name'=>'required|max:255',
             'description'=>'required|max:255',
             'packsize'=>'required|max:255',
             'catagory'=>'required',
             'productType'=>'required',
             'price' => 'required|numeric',
             'Kd_id' => 'required',
             'Qty' => 'required'
             ]);
        // $product_catagor = ProductCatagory::find($id);
        $products = new product;
        $products->name = $request->name;
        $image = $request->image;
        $imagename = time(). '.' . $image->getClientOriginalExtension();
        $request->image->move('assets/product_img',$imagename);
        $products->image = $imagename;
        $products->description = $request->description;
        $products->price = $request->price;
        $products->packsize = $request->packsize;
        $products->catagory_id = $request->catagory;
        $products->ProductType_id = $request->productType;
        $products->Qty = $request->Qty;
        $products->KD_ID = $request->Kd_id;
        $products->save();
        Alert::toast('Product Added Successfully', 'success');
        return redirect('/admin/view/product');
    }

    public function view_product()
    {
        $products= product::all();
        return view('admin.viewProducts',compact('products'));

    }
    public function edit_product($id)
    {
        $catagory = ProductCatagory::all();
        $productType= ProductType::all();
        $products = product::find($id);
        $key_distro = key_distro::join('users','users.id','=','key_distros.user_id')->get();
        return view('admin.editProducts',compact('products','catagory','productType', 'key_distro'));

    }
    public function edited_product_store(Request $request,$id)
    {
        $request->validate([
             'image'=>'image|mimes:jpg,png,jpeg|max:5048',
             'name'=>'required|max:255',
             'description'=>'required|max:255',
             'packsize'=>'required|max:255',
             'catagory'=>'required',
             'productType'=>'required',
             'price' => 'required',
             //'KD_ID' => 'required',
             ]);
        $products = product::find($id);
        $productImage = $request->image;
        if($productImage != null)
        {
        $image = $request->image;
        $imagename = time(). '.' . $image->getClientOriginalExtension();
        $request->image->move('assets/product_img',$imagename);
        $products->image = $imagename;
        }
        else
        {
            $products->image = $request->old_image;
        }
        $products->name = $request->name;
        $products->description = $request->description;
        $products->price = $request->price;
        $products->packsize = $request->packsize;
        $products->catagory_id = $request->catagory;
        $products->productType_id = $request->productType;
        $products->save();
        Alert::toast('Product Updated Successfully', 'success');
        return redirect('/admin/view/product');
    }

    public function delete_product($id)
    {
        $products = product::find($id);
        $products->delete();
        Alert::toast('Product Deleted Successfully', 'success');
        return redirect('/admin/view/product');
    }
    public function add_catagory()
    {
        return view('admin.addCatagories');
    }
     public function store_catagory(Request $request)
    {
        $request->validate([
            'catagoryName' => 'required|max:255',
            'description'=>'required|max:255',
            'image'=>'required|image|mimes:jpg,png,jpeg|max:5048',
        ]);
        $product_catagories = new ProductCatagory;
        $product_catagories->catagoryName = $request->catagoryName;
        $image = $request->image;
        $imagename = time(). '.' . $image->getClientOriginalExtension();
        $request->image->move('assets/catagory_img',$imagename);
        $product_catagories->image = $imagename;
        $product_catagories->description = $request->description;
        $product_catagories->save();
        Alert::toast('Catagory Added Successfully', 'success');
         return redirect('/admin/view/catagory');
    }

    public function view_catagory()
    {
        $product_catagories= ProductCatagory::all();
        return view('admin.viewCatagories',compact('product_catagories'));

    }
    public function edit_productCatagory($id)
    {
        $product_catagories = ProductCatagory::find($id);
        return view('admin.editCatagory',compact('product_catagories'));

    }

    public function edited_product_catagories(Request $request,$id)
    {
        $request->validate([
            'catagoryName' => 'required|max:255',
            'description'=>'required|max:255',
            'image'=>'image|mimes:jpg,png,jpeg|max:5048',
        ]);

        $product_catagories = ProductCatagory::find($id);
        $catagoryImage = $request->image;
        if($catagoryImage != null)
        {
        $image = $request->image;
        $imagename = time(). '.' . $image->getClientOriginalExtension();
        $request->image->move('assets/catagory_img',$imagename);
        $product_catagories->image = $imagename;
        }
        else
        {
            $product_catagories->image = $request->old_image;
        }
        $product_catagories->catagoryName = $request->catagoryName;
        $product_catagories->description = $request->description;


        $product_catagories->save();
        Alert::toast('Catagory Updated Successfully', 'success');
        return redirect('/admin/view/catagory');
    }

    public function delete_ProductCatagory($id)
    {
        $product_catagories = ProductCatagory::find($id);
        $product_catagories->delete();
        Alert::toast('Catagory Deleted Successfully', 'success');
        return redirect('/admin/view/catagory');
    }
      public function add_productType(Request $request)
    {
        // $key_distro = key_distro::join('users','users.id','=','key_distros.user_id')->get();
        $catagory = ProductCatagory::all();

        return view('admin.addProductTypes',compact('catagory'));
    }

     public function store_productType(Request $request)
    {
        $request->validate([
            'productTypeName' => 'required|max:255',
            'description'=>'required|max:255',
            'catagory' => 'required',

        ]);
        // $product_catagor = ProductCatagory::find($id);
        $product_types = new ProductType;
        $product_types->productTypeName = $request->productTypeName;
        $product_types->description = $request->description;
        $product_types->catagory_id = $request->catagory;
        $product_types->save();
        Alert::toast('Product Type Added Successfully', 'success');
        return redirect('/admin/view/productType');
    }

    public function view_ProductType()
    {
        $product_types = ProductType::all();
        return view('admin.viewProductTypes',compact('product_types'));

    }

    public function edit_productType($id)
    {
        $product_types = ProductType::find($id);
        $catagory = ProductCatagory::all();
        return view('admin.editProductType',compact('catagory','product_types'));

    }
    public function edited_productType_store(Request $request,$id)
    {
        $request->validate([
            'productTypeName' => 'required',
            'description' => 'required',
            'catagory' => 'required',
        ]);
        $product_types = ProductType::find($id);
        $product_types->productTypeName = $request->productTypeName;
        $product_types->description = $request->description;
        $product_types->catagory_id = $request->catagory;
        $product_types->save();
        Alert::toast('Product Type Updated Successfully', 'success');
        return redirect('/admin/view/productType');
    }

    public function delete_productType($id)
    {
        $product_types = ProductType::find($id);
        $product_types->delete();
        Alert::toast('Product Type Deleted Successfully', 'success');
        return redirect('/admin/view/productType');
    }
    public function activate_user($id)
    {
        $user = user::find($id);
        $user->status = 'active';
        $user->save();
        Alert::toast('Successfully Activated', 'success');
        return redirect()->back();
    }
     public function deactivate_user($id,Request $request)
    {
        $user = user::find($id);
        $user->status = $request->deactivate;
        $user->save();
        Alert::toast('Successfully Deactivated', 'success');
        return redirect()->back();
    }


    public function newUserList()
    {
        $userList=user::get();
        return view('admin.userList',compact('userList'));
    }


    public function create_client()
    {
        $businessType=businessType::all();
        $idType= idType::all();
        $key_distro = key_distro::join('users','users.id','=','key_distros.user_id')->get();;
        return view('admin.registerClient',compact('businessType','key_distro','idType'));
    }

    public function store_client(Request $request)
    {
        $err = $request->validate([
            'firstName' => ['required', 'string', 'max:255'],
            'middleName' => ['required', 'string', 'max:255'],
            'lastName' => ['required', 'string', 'max:255'],
            'userName' => ['required', 'string', 'max:255','unique:users'],
            'userType' => ['required', 'string', 'max:255'],
            // 'password' => ['required', 'min:6'],
            // 'PinCode' => ['required', 'min:4'],
            'QRPassword' => ['required'],
            'address' =>['required', 'string'],
            // 'mobile' => ['digits:10'],
            'id_path' => ['image','mimes:jpg,png,jpeg','max:5048'],
            'kd' =>['required'],
            'status' => ['required'],
            // 'lat' => ['required'],
            // 'lng' => ['required'],
        ]);
           $imagename = time() . '.' . $request->id_path->getClientOriginalExtension();
           $request->id_path->move('assets/gov_img',$imagename);
        $user = user::create([
            'firstName' => $request->firstName,
            'middleName'=> $request->middleName,
            'lastName'=> $request->lastName,
            'userName'=> $request->userName,
            'password'=> Hash::make($request['password']),
            'userType'=> $request->userType,
            'status' => $request->status,
        ]);
           $client= client::create([
            'user_id' => $user->id,
            'PinCode' => $request->pinCode,
            'QRPassword'=>$request->QRPassword,
            'client_address'=> $request->address,
            'client_mobile'=>$request->mobile,
            'id_filepath' => $imagename,
            'ID_type' => $request->idType,
            'client_businessName'=> $request->businessName,
            'client_businessType'=> $request->businessType,
            'client_BusinessRegisteration'=> $request->businessRegisteration,
            'client_mobile'=>$request->mobile,
            'client_latitude'=> $request->lat,
            'client_longtude'=> $request->lng,
            'distro_id'=> $request->kd,
            'client_yearsInBusiness'=>$request->businessEstablishmentYear,
            ]);

        Alert::toast('Successfully Registered', 'success');
        return redirect('/admin/view/clients');
    }
    public function create_user()
    {
        return view('admin.registerUser');
    }
    public function store_user(Request $request){
        $request->validate([
            'firstName' => ['required', 'string', 'max:255'],
            'middleName' => ['required', 'string', 'max:255'],
            'lastName' => ['required', 'string', 'max:255'],
            'userName' => ['required', 'string', 'max:255','unique:users'],
            'email' => [ 'string', 'email', 'max:255', 'unique:users'],
            'userType' => ['required', 'string', 'max:255'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
        ]);

         $user = user::create([
            'firstName'=>$request->firstName,
            'middleName'=>$request->middleName,
            'lastName'=> $request->lastName,
            'userName'=> $request->userName,
            'email' => $request->email,
            'password'=>Hash::make($request['password']),
            'userType'=>$request->userType,
            'status'=>$request->status,
        ]);
        Alert::toast('successfully Registered', 'success');
        return redirect('/user/list');
    }
    public function view_clients()
    {
        $client = client::join('users','users.id', '=','clients.user_id')->get();
        $key_distro=key_distro::join('users','users.id','=','key_distros.user_id')->get();
        return view('admin.showClients',compact('client','key_distro'));

    }

    public function orderIndex()
    {
        $order = order::join('users','users.id','=','orders.client_id')
        ->join('clients','clients.user_id','=','orders.client_id')
        ->where('orders.createdDate',today())
        ->get(['users.firstName','users.middleName','users.lastName','orders.id','orders.createdDate','orders.deliveryStatus', 'clients.distro_id','KD_id']);
        return view('admin.showOrders',compact('order'));

    }
    public static function getname($id)
    {
        $kd = DB::table('key_distros')
        ->join('users','users.id','=','key_distros.user_id')
        ->where('key_distros.id', $id)
        ->get(['users.firstName','users.middleName','users.lastName']);
        return $kd;
    }
    public function orderHistory()
    {
         $order = order::join('users','users.id','=','orders.client_id')
        ->join('clients','clients.user_id','=','orders.client_id')
        ->join('key_distros', 'key_distros.id','=','clients.distro_id')
        ->get(['users.firstName','users.middleName','users.lastName','orders.id','orders.createdDate','orders.deliveryStatus', 'clients.distro_id']);

        $client = order::join('users','users.id','=','orders.client_id')
        ->join('clients','clients.user_id','=','orders.client_id')->get(['users.firstName','users.middleName'
        ,'users.lastName','orders.id','orders.createdDate','orders.deliveryStatus']);

        $kd = order::join('users','users.id','=','orders.KD_id')->
        join('key_distros','key_distros.user_id','=','orders.KD_id')
        ->where('orders.createdBy',auth()->user()->id)->get();

        return view('admin.orderHistory',compact('client','kd','order'));

    }
    public function undeliveredIndex( )
    {
        $rom = undeliveredOrders::join('users','users.id','=','undelivered_orders.rom_id')
        ->join('roms','roms.user_id','=','undelivered_orders.rom_id')->get(['users.firstName','users.middleName'
        ,'users.lastName','undelivered_orders.*'])->sortDesc();

        $deliveredProducts = delivery1Products::join('delivery1s','delivery1s.id','=','delivery1_products.delivery1_id')
        ->join('products','products.id','=','delivery1_products.product_id')
        ->where('delivery1s.kd_id',auth()->user()->id)->get();
        $count = $deliveredProducts->count();
        return view('admin.undeliveredOrders',compact('deliveredProducts','rom'));

    }
    public function undeliveredDetails(Request $request )
    {
        $rom_id=$request->delivery1_id;
        $deliveredProducts=undelivered1Products::join('undelivered_orders','undelivered_orders.id','=','undelivered1_products.undelivered1_id')
        ->join('products','products.id','=','undelivered1_products.product_id')
        ->where('undelivered1_products.undelivered1_id',$rom_id)->get();
        return view('admin.undeliveredDetails',compact('deliveredProducts'));

    }

}
