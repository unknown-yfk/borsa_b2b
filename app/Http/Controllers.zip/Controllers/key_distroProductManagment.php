<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProductCatagory;
use App\Models\ProductType;
use App\Models\product;
use App\Models\user;
use App\Models\key_distro;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\Validator;
use Auth;

class key_distroProductManagment extends Controller
{
    public function add_product(Request $request)
    {
        $catagory = ProductCatagory::all();
        $productType= ProductType::all();
        return view('KD.addProducts',compact('catagory', 'productType'));
    }
     public function store_product(Request $request)
    {
       $request->validate([
             'image'=>'required|image|mimes:jpg,png,jpeg|max:5048',
             'name'=>'required|max:255',
             'description'=>'required|max:255',
             'packsize'=>'required|max:255',
             'catagory'=>'required',
             'productType'=>'required',
             'price' => 'required|numeric',
             'Qty' => 'required|numeric',
             ]);
        // $product_catagor = ProductCatagory::find($id);
        $products = new product;
        $products->name = $request->name;
        $image = $request->image;
        $imagename = time(). '.' . $image->getClientOriginalExtension();
        $request->image->move('assets/product_img',$imagename);
        $products->image = $imagename;
        $products->description = $request->description;
        $products->price = $request->price;
        $products->Qty = $request->Qty;
        $products->packsize = $request->packsize;
        $products->catagory_id = $request->catagory;
        $products->ProductType_id = $request->productType;
        $products->KD_ID = Auth::id();
        $products->save();
        Alert::toast('Product Added Successfully', 'success');
        return redirect('/key_distro/view/product');
    }
    public function view_product()
    {
        $products = product::where('KD_ID', Auth::id())->get();
        return view('KD.viewProducts',compact('products'));

    }
    public function edit_product($id)
    {
        $catagory = ProductCatagory::all();
        $productType= ProductType::all();
        $products = product::find($id);
        return view('KD.editProducts',compact('products','catagory','productType'));

    }
    public function edited_product_store(Request $request,$id)
    {
        $request->validate([
             'image'=>'image|mimes:jpg,png,jpeg|max:5048',
             'name'=>'required|max:255',
             'description'=>'required|max:255',
             'packsize'=>'required|max:255',
             'catagory'=>'required',
             'productType'=>'required',
             'price' => 'required|numeric',
             'Qty'=> 'required|numeric'

             ]);
        $products = product::find($id);
        $productImage = $request->image;
        if($productImage != null)
        {
        $image = $request->image;
        $imagename = time(). '.' . $image->getClientOriginalExtension();
        $request->image->move('assets/product_img',$imagename);
        $products->image = $imagename;
        }
        else
        {
            $products->image = $request->old_image;
        }
        $products->name = $request->name;
        $products->description = $request->description;
        $products->price = $request->price;
        $products->Qty = $request->Qty;
        $products->packsize = $request->packsize;
        $products->catagory_id = $request->catagory;
        $products->productType_id = $request->productType;
        $products->KD_ID = Auth::id();
        $products->save();
        Alert::toast('Product Updated Successfully', 'success');
        return redirect('/key_distro/view/product');
    }

    public function delete_product($id)
    {
        $products = product::find($id);
        $products->delete();
        Alert::toast('Product Deleted Successfully', 'success');
        return redirect('/key_distro/view/product');
    }
}
