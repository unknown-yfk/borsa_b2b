@include('layout.header')
<body class="sb-nav-fixed">
    @include('nav.kd_navbar')
        <div id="layoutSidenav">
            @include('Sidenavbar.kdSidebar')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                            <h1 class="mt-4">Handover Report</h1>
                            <div class="row">
                            <div class="card-body">
                            <div class="card mb-4">
                            <div class="card-header">
                                <strong>Report</strong>
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>Delivery ID</th>
                                            <th>Delivery Status</th>
                                            <th>Delivery  Date</th>
                                            <th>Order ID</th>
                                            <th>Handoverd To</th>
                                            <th>Handover Status</th>
                                            <th>Handover Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                      @foreach($handover as $handover)
                                      <tr>
                                            <td>{{$handover->id}}</td>
                                            <td>{{$handover->confirmStatus}}</td>
                                            <td>{{$handover->created_at}}</td>
                                            <td>{{$handover->order_id}}</td>
                                            <td>{{$handover->firstName}} {{$handover->middleName}} {{$handover->lastName}}</td>
                                            <td>{{$handover->handoverStatus}}</td>
                                            <td>{{$handover->createdDate}}</td>
                                        </tr>
                                @endforeach
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
    @include('layout.footer')
            </div>
        </div>
   </body>
</html>

