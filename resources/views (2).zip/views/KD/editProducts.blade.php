@include('layout.header')
<body class="sb-nav-fixed">
    @include('nav.admin_navbar')
        @include('sweetalert::alert')
        <div id="layoutSidenav">
            @include('Sidenavbar.adminSidebar')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Edit Product</h1>
                        <div class="row">
                        <div class="card mb-4">
                            <div class="card-header">
                               You Can Edit The Product Here!
                            </div>
                            <div class="card-body">
                            <div class="container rounded bg-white mt-5 mb-5">
                                <div class="row mt-2">
                                    <center>
                        <form action="{{url('/key_distro/edit/product/post',$products->id)}}" method= "POST" enctype="multipart/form-data"></center>
                            @csrf
                                <div class="mb-3">
                                 <label><strong> Product Name</strong></label>
                                   <input type="text" id="name" name="name" value="{{ $products->name }}" class="form-control">
                                </div>

                                <div class="mb-3">
                                 <label><strong> Product Image</strong></label>
                                  <img src="../../../assets/product_img/{{$products->image}}" class="rounded float-start" alt="Product Image" width="100rem" height="100rem">
                                   <input type="file" id="image" name="image" class="form-control">
                                   <input type="hidden" id="old_image"  name="old_image" value="{{$products->image}}">
                                </div>

                                <div class="mb-3"><label><strong>Select Catagory</strong></label>

                                     <select id="catagory" name="catagory" value=""class="form-control" required>
                                         <option value=""></option>
                                         @foreach($catagory as $p)
                                            <option value="{{$p->id}}" {{$products->catagory_id === $p->id ? 'selected' : '' }}>{{ $p->catagoryName	 }}</option>
                                         @endforeach
                                    </select>
                                </div>
                                <div class="mb-3"><label><strong>Select Product Type</strong></label>
                                   <select id="productType" name="productType" class="form-control" required>
                                            <option value=""></option>
                                        @foreach($productType as $p )
                                            <option value="{{$p->id}}" {{$products->productType_id === $p->id ? 'selected' : '' }}>{{ $p->productTypeName }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-3">
                                 <label><strong> Price</strong></label>
                                   <input type="number" pattern="[0-9]+([\.,][0-9]+)?" step="0.01" id="price" name="price" value="{{ $products->price }}"class="form-control">
                                </div>
                                <div class="mb-3">
                                 <label><strong> Quantity</strong></label>
                                   <input type="number" id="Qty" name="Qty" value="{{ $products->Qty }}"class="form-control">
                                </div>
                                <div class="mb-3">
                                 <label><strong>Pack-Size</strong></label>
                                   <input id="packsize" name="packsize" value="{{ $products->packsize}}"class="form-control">
                                </div>

                                <div class="mb-3">
                                 <label><strong>Description</strong></label>
                                <input type="text"  id="description" name="description" value="{{ $products->description }}"rows="5" class="form-control" required>
                                </div>
                                <input type="hidden" name="old_image" value="{{ $products->image }}">
                                <div class="col-md-6">
                                    <input type="submit" class="btn btn-outline-success" value="Update Product">
                                </div>
                            </div>
                        </form>

                </div>
            </div>
        </div>
    </div>
</main>
@include('layout.footer')
</div>
</div>
</body>
</html>
