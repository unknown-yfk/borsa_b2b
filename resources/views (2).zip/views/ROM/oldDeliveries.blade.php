@include('layout.header')
    <body class="sb-nav-fixed">
        @include('nav.rom_navbar')
        <div id="layoutSidenav">
            @include('Sidenavbar.romSidebar')
           <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Delivery History</h1>
                        <div class="row">
                        <div class="card mb-4 mt-2">
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>Delivery ID</th>
                                            <th>Delivered from</th>
                                            <th>Order ID</th>
                                            <th>Confirmation Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                      @foreach($delivery as $delivery)
                                      <tr>
                                            <td>{{$delivery->id}}</td>
                                            <td>{{$delivery->firstName}} {{$delivery->middleName}} {{$delivery->lastName}}</td>
                                            <td>{{$delivery->order_id}}</td>
                                            <td>{{$delivery->confirmationStatus}}</td>
                                            <td>
                                            <form action="{{ ('/rom/delivery/details') }}" method="POST">
                                               @csrf
                                               <input type="hidden" value="{{$delivery->id}}" name="delivery1_id" >
                                             <button type="submit" class="btn btn-outline-success">View Details</button>
                                            </form>
                                        </td>
                                        </tr>
                                @endforeach
                                </table>
                            </div>
                        </div>
                   </div>
                </div>
            </main>
            @include('layout.footer')
        </div>
    </div>
   </body>
</html>
