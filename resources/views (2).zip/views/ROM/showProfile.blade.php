@include('ROM.header')
<body class="sb-nav-fixed">
   @include('nav.rom_navbar')
        <div id="layoutSidenav">
          @include('Sidenavbar.romSidebar')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">My Profile</h1>
                        <div class="row">
                        <div class="card mb-4">
                            <div class="card-body">
                            <div class="container rounded bg-white mt-5 mb-5">
                    <div class="row mt-2">
                    @foreach($romProfile as $profile)
                    <div class="col-md-6">
                        <img src="../../assets/users_img/{{Auth::user()->userPhoto}}" class="rounded-circle shadow-4-strong" alt="{{ Auth::user()->userName }}" width="100rem" height="100rem">

                    </div>
                    </div>
                    <div class="row mt-2">
                    <div class="col-md-6"><label class="labels"><strong> First Name</strong></label>
                    <p class="form-control">{{ $profile->firstName }}</p></div>
                    <div class="col-md-6"><label class="labels"><strong>Middle Name</strong></label>
                    <p class="form-control" >{{$profile->middleName}}</p></div>
                    <div class="col-md-6"><label class="labels"><strong>Last Name</strong></label>
                    <p class="form-control">{{$profile->lastName}}</p></div>
                    <div class="col-md-6"><label class="labels"><strong>User Name</strong></label>
                    <p class="form-control" >{{$profile->userName}}</p></div>
                    <div class="col-md-6"><label class="labels"><strong>Email</strong></label>
                    <p class="form-control">{{$profile->email}}</p></div>
                    <div class="col-md-6"><label class="labels"><strong>Resident Address</strong></label>
                    <p class="form-control" >{{$profile->address}}</p></div>
                    <div class="col-md-6"><label class="labels"><strong>Phone Number</strong></label>
                    <p class="form-control">{{$profile->mobile}}</p></div>

                    <div class="col-md-12">
                          <label class="labels"><strong>Your ID</strong></label>
                         <img src="../../assets/gov_img/{{$profile->id_filepath}}" class="rounded float-start" alt="{{ $profile->id_file_path }}" width="100rem" height="100rem">

                    </div>
                    <div class="col-md-6"><label class="labels"><strong>ID Type</strong></label>
                    <p class="form-control" >{{$profile->ID_type}}</p></div>
                    <div class="col-md-6"><label class="labels"><strong>ID Number</strong></label>
                    <p class="form-control">{{$profile->ID_number}}</p></div>
                    <div class="col-md-6"><label class="labels"><strong>ID Issue Date</strong></label>
                    <p class="form-control" >{{$profile->ID_issue_date->format('y-m-d')}}</p></div>
                    <div class="col-md-6"><label class="labels"><strong>ID Expiry Date</strong></label>
                    <p class="form-control">{{$profile->ID_expiry_date->format('y-m-d')}}</p></div>
                          @endforeach
                        </div>
                        <div class="row mt-2">
                            <center><a href="/rom/update/edit"><button class="btn btn-primary">Update</button></a></center>
                        </div>
                    </div>
                </div>
            </div>
<script src="{{url ('js/datatables-simple-demo.js') }}"></script>
        </main>
        @include('layout.footer')
    </div>
</div>
</body>
</html>
