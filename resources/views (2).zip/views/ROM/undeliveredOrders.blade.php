@include('ROM.header')

<body class="sb-nav-fixed">
    @include('nav.rom_navbar')
        <div id="layoutSidenav">
            @include('Sidenavbar.romSidebar')
             <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Undelivered Orders</h1>
                        <div class="row">
                        <div class="card mb-4">
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>No.</th>
                                            <th>Order ID</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                      @foreach($undelivered as $undelivered)

                                      <tr>
                                            <td>{{$undelivered->id}}</td>
                                            <td>{{$undelivered->order_id}}</td>
                                            <td>{{$undelivered->created_at->format('d/m/y')}}</td>
                                            <td>
                                            <form action="{{ ('/romUndeliveredDetails') }}" method="POST">
                                               @csrf
                                               <input type="hidden" value="{{$undelivered->id}}" name="delivery1_id" >
                                             <button type="submit" class="btn btn-outline-success">View Details</button>
                                            </form>
                                            </td>
                                        </tr>
                                @endforeach
                            </table>
                         </div>
                        </div>
                   </div>
                </div>
            </main>
            @include('layout.footer')
        </div>
    </div>
</body>
</html>
