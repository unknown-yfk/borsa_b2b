<footer class="py-4 bg-light mt-auto" id="footer">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-right float-right justify-content-between small">
            <div class="text-muted">Copyright &copy; Elebat Solutions 2022</div>
            <div>
            </div>
        </div>
    </div>
</footer>
