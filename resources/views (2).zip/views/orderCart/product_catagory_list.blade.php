@include('dashboard.header')
<style>
    #footer {
   position: fixed !important;
   bottom: 0 !important;
   width: 100% !important;
   height: 5px !important;   /* Height of the footer */
}
</style>
<body class="sb-nav-fixed">
    @include('orderCart.nav_agent_bar')
    <div id="layoutSidenav">
        @include('Sidenavbar.agentSidebar')
            <div id="layoutSidenav_content">
            <main>
                @extends('layout.catagoryHeader')
                @section('content')
                @include('sweetalert::alert')
                <div class="container px-6 mx-auto">
                    <h3 class="text-2xl font-medium text-gray-700">Catagories</h3>
                    <div class="grid grid-cols-1 gap-6 mt-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                        @foreach ($productsCatagories as $catagory)
                             <div class="w-full max-w-sm mx-auto overflow-hidden rounded-md shadow-md">
                                 <img src="../../assets/catagory_img/{{$catagory->image}}" alt="Catagory Image" class="w-full max-h-60">
                                <div class="flex items-end justify-end w-full bg-cover"></div>
                                <div class="px-5 py-3">
                                <h3 class="text-gray-700 uppercase"><strong>{{ $catagory->catagoryName }}</strong></h3>
                                <span class="mt-2 text-gray-600">{{ $catagory->description }} </span>
                                <form action="{{url('product/category',$catagory->id)}}" method="GET">
                                    <button class="px-4 py-2 text-white bg-blue-800 rounded">View Products</button>
                                </form>
                            </div>
                        </div>
                        @endforeach
                    </div>
                    <br>
                    <br>
                </div>
            <main>
            @include('layout.footer')
        </div>
    </div>
    @endsection
    <style>
        </style>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="{{ url('js/scripts.js') }}"></script>
    <script src=" https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="{{url ('assets/demo/chart-area-demo.js')}}"></script>
    <script src="{{url ('assets/demo/chart-bar-demo.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="{{url ('js/datatables-simple-demo.js') }}"></script>
    <link href="{{ url('css/styles.css') }}" rel="stylesheet"/>
</body>
</html>
