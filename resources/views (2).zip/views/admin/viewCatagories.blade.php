@include('dashboard.header')
<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
<body class="sb-nav-fixed">
    @include('nav.admin_navbar')
    <div id="layoutSidenav">
        @include('Sidenavbar.adminSidebar')
            <div id="layoutSidenav_content">
            <main>
                @include('sweetalert::alert')
                <div class="container px-6 mx-auto">
                    <h3 class="text-2xl font-medium text-gray-700">Catagory List</h3>
                    <div class="grid grid-cols-1 gap-6 mt-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                        @foreach ($product_catagories as $catagory)
                             <div class="w-full max-w-sm mx-auto overflow-hidden rounded-md shadow-md">
                                 <img src="../../../assets/catagory_img/{{$catagory->image}}" alt="Catagory Image" class="w-full max-h-60">
                                <div class="flex items-end justify-end w-full bg-cover"></div>
                                <div class="px-5 py-3">
                                <h5 class="text-gray-700 uppercase">{{ $catagory->catagoryName }}</h5><br>

                                <span class="mt-2 text-gray-500"> <strong>Description : </strong>{{ $catagory->description }}</span><br>
                                <br><br>
                                <a href="{{url('admin/edit/catagory',$catagory->id)}}">
                                  <button class="btn btn-outline-success">
                                    {{ __('Edit Catagory') }}
                                  </button>
                                </a>
                                  <br> <br>

                                <a href="{{url('admin/delete/catagory',$catagory->id)}}">
                                 <button class="btn btn-outline-danger" onclick="return confirm('Do You Want To Delete This Catagory?')">
                                    Delete Catagory
                                  </button>
                                </a>



                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
            <main>
            @include('layout.footer')
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="{{ url('js/scripts.js') }}"></script>
    <script src=" https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="{{url ('assets/demo/chart-area-demo.js')}}"></script>
    <script src="{{url ('assets/demo/chart-bar-demo.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="{{url ('js/datatables-simple-demo.js') }}"></script>
    <link href="{{ url('css/styles.css') }}" rel="stylesheet"/>
</body>
</html>
