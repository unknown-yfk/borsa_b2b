@include('layout.header')
<body class="sb-nav-fixed">
    @include('nav.admin_navbar')
        @include('sweetalert::alert')
        <div id="layoutSidenav">
            @include('Sidenavbar.adminSidebar')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Add Product Types</h1>
                        <div class="row">
                        <div class="card mb-4">
                            <div class="card-header">
                               Add Product Types Here!
                            </div>
                            <div class="card-body">
                            <div class="container rounded bg-white mt-5 mb-5">
                                <div class="row mt-2">
                                    <center>
                        <form action="{{url('admin/StoreProductTypes')}}" method= "POST" enctype="multipart/form-data"></center>
                    @csrf
                    <div class="mb-3">
                     <label> Product Type Name</label>
                       <input type="text" id="productTypeName" name="productTypeName" class="form-control"required>
                    </div>
                    <div class="mb-3"><label>Select Catagory</label>
                         <select id="catagory" name="catagory" class="form-control" required>
                             @foreach($catagory as $p)
                                {{-- <option value=""></option> --}}
                                <option value="{{$p->id}}"> {{$p->catagoryName }}
                                {{-- </option> --}}
                             @endforeach
                        </select>
                    </div>

                    <div class="mb-3">
                     <label> Description</label>
                       <textarea id="description" name="description" rows="5" class="form-control"></textarea>
                    </div>

                    <div class="col-md-6">
                        <button type="submit" class="btn btn-outline-success">Save Product Type</button>

                     </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</main>
@include('layout.footer')
</div>
</div>
</body>
</html>
