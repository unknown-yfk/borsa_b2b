@include('layout.header')
<body class="sb-nav-fixed">
    @include('nav.admin_navbar')
        <div id="layoutSidenav">
            @include('Sidenavbar.adminSidebar')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Client List</h1>
                        <div class="row">
                        <div class="card mb-4">
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>User ID</th>
                                            <th>Full Name</th>
                                            <th>User Name</th>
                                            <th>Account Status</th>
                                            <th>Address</th>
                                            <th>Mobile</th>
                                            <th>Bussiness Name</th>
                                            <th>Bussiness Type
                                            <th>Registration</th>
                                            <th>Year In Bussiness</th>
                                            <th>Gelocation</th>
                                            <th>Distributor</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                      @foreach($client as $user)
                                      <tr>
                                            <td>{{$user->id}}</td>
                                            <td>{{$user->firstName}} {{$user->middleName}} {{$user->lastName}}</td>
                                            <td>{{$user->userName}}</td>
                                            <td>{{$user->status}}</td>
                                            <td>{{$user->client_address}}</td>
                                            <td>{{$user->client_mobile}}</td>
                                            <td>{{$user->client_businessName}}</td>
                                            <td>{{$user->client_businessType}}</td>
                                            <td>{{$user->client_BusinessRegisteration}}</td>
                                            <td>{{$user->client_yearsInBusiness}}</td>
                                            <td>{{$user->client_longtude}} {{$user->client_latitude}}</td>
                                            <td>{{$user->distro_id}}</td>
                                        </tr>
                                @endforeach
                                </table>
                                </div>
                             </div>
                        </div>
                    </div>
                </main>
            </div>
    </div>
</div>
                </main>
                @include('layout.footer')
    </div>
    </div>
</body>
</html>
