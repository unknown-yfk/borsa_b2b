@include('layout.header')
<body class="sb-nav-fixed">
    @include('nav.admin_navbar')
        @include('sweetalert::alert')
        <div id="layoutSidenav">
            @include('Sidenavbar.adminSidebar')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Edit Product Type</h1>
                        <div class="row">
                        <div class="card mb-4">
                            <div class="card-header">
                               You Can Edit The Product Type Here!
                            </div>
                            <div class="card-body">
                            <div class="container rounded bg-white mt-5 mb-5">
                                <div class="row mt-2">
                                    <center>
                        <form action="{{url('/admin/editedProductTypeStore',$product_types->id)}}" method= "POST" enctype="multipart/form-data"></center>
                            @csrf
                                <div class="mb-3">
                                 <label> Product Type Name</label>
                                   <input type="text" id="productTypeName" name="productTypeName" value="{{ $product_types->productTypeName }}" class="form-control">
                                </div>
                                <div class="mb-3"><label>Select Catagory</label>
                                     <select id= "catagory" name ="catagory" value="" class="form-control" required>
                                         <option value=""></option>
                                         @foreach($catagory as $p)
                                         <option value="{{$p->id}}" {{$product_types->catagory_id === $p->id ? 'selected' : '' }}>{{ $p->catagoryName}}</option>
                                            {{-- <option value="{{$p->id}}"> {{Helper::get_CategoryName($p->id) }}</option> --}}
                                         @endforeach
                                    </select>
                                </div>
                                <div class="mb-3">
                     <label> Description</label>
                        <input type="text"  id="description" name="description" value="{{ $product_types->description }}"rows="5" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <input type="submit" class="btn btn-outline-success" value="Update Product Type">
                     </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</main>
@include('layout.footer')
</div>
</div>
</body>
</html>
