@include('layout.header')
@include('layout.map')

<body class="sb-nav-fixed">
    @include('nav.admin_navbar')
    @include('sweetalert::alert')
    <div id="layoutSidenav">
        @include('Sidenavbar.adminSidebar')
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">User Registeration</h1>
                    <div class="row">
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                Fill the form and click submit to complete User Registeration
                            </div>
                            <div class="card-body">
                                <div class="container rounded bg-white mt-5 mb-5">

                                    <div class="row mt-2">
                                        <center>
                                            <form method="POST" action="/admin/create/user/post">
                                        </center>
                                        @csrf
                                        <div class="row mb-3">
                                            <label for="firstName"
                                                class="col-md-4 col-form-label text-md-end">{{ __('First Name') }}</label>
                                            <div class="col-md-6">
                                                <input id="firstName" type="text"
                                                    class="form-control @error('firstName') is-invalid @enderror"
                                                    name="firstName" value="{{ old('name') }}" required
                                                    autocomplete="firstName" autofocus>

                                                @error('firstName')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="middleName"
                                                class="col-md-4 col-form-label text-md-end">{{ __('Middle Name') }}</label>

                                            <div class="col-md-6">
                                                <input id="middleName" type="text"
                                                    class="form-control @error('middleName') is-invalid @enderror"
                                                    name="middleName" value="{{ old('name') }}" required
                                                    autocomplete="Middle Name" autofocus>

                                                @error('middle name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="lastName"
                                                class="col-md-4 col-form-label text-md-end">{{ __('Last Name') }}</label>
                                            <div class="col-md-6">
                                                <input id="lastName" type="text"
                                                    class="form-control @error('lastName') is-invalid @enderror"
                                                    name="lastName" value="{{ old('name') }}" required
                                                    autocomplete="lastName" autofocus>
                                                @error('last name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="userName"
                                                class="col-md-4 col-form-label text-md-end">{{ __('User Name') }}</label>

                                            <div class="col-md-6">
                                                <input id="userName" type="text"
                                                    class="form-control @error('userName') is-invalid @enderror"
                                                    name="userName" value="{{ old('name') }}" required
                                                    autocomplete="userName" autofocus>

                                                @error('userName')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="email"
                                                class="col-md-4 col-form-label text-md-end">{{ __('Email Address') }}</label>

                                            <div class="col-md-6">
                                                <input id="email" type="email"
                                                    class="form-control @error('email') is-invalid @enderror"
                                                    name="email" value="{{ old('email') }}" autocomplete="email">

                                                @error('email')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="userType"
                                                class="col-md-4 col-form-label text-md-end">{{ __('Select User Type') }}</label>
                                            <div class="col-md-6">

                                                <select id="userType" name="userType" class="form form-control">
                                                    <option value="client">Client</option>
                                                    <option value="key distributor">Key Distributor</option>
                                                    <option value="ROM">ROM</option>
                                                    <option value="RSP">RSP</option>
                                                    <option value="agent">Agent</option>
                                                </select>
                                                @error('userType')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="status"
                                                class="col-md-4 col-form-label text-md-end">{{ __('Status') }}</label>
                                            <div class="col-md-6">
                                                <select id="status" name="status" class="form form-control">
                                                    <option value=""></option>
                                                    <option value="active">Active</option>
                                                    <option value="inactive">Inactive</option>
                                                </select>
                                                @error('status')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="password"
                                                class="col-md-4 col-form-label text-md-end">{{ __('Password') }}</label>

                                            <div class="col-md-6">
                                                <input id="password" type="password"
                                                    class="form-control @error('password') is-invalid @enderror"
                                                    name="password" required autocomplete ="off">

                                                @error('password')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="password-confirm"
                                                class="col-md-4 col-form-label text-md-end">{{ __('Confirm Password') }}</label>

                                            <div class="col-md-6">
                                                <input id="password-confirm" type="password" class="form-control"
                                                    name="password_confirmation" required autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="row mb-0">
                                            <div class="col-md-6 offset-md-4">
                                                <button type="submit" class="btn btn-outline-success"
                                                    onsubmit="setTimeout()">
                                                    {{ __('Register') }}
                                                </button>
                                            </div>
                                        </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
            </main>
            @include('layout.footer')
        </div>
    </div>
</body>

</html>
