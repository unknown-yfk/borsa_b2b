@include('dashboard.header')
<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
<body class="sb-nav-fixed">
    @include('nav.admin_navbar')
    <div id="layoutSidenav">
        @include('Sidenavbar.adminSidebar')
            <div id="layoutSidenav_content">
            <main>
                @include('sweetalert::alert')
                <div class="container px-6 mx-auto">
                    <h3 class="text-2xl font-medium text-gray-700">Product Type List</h3>
                    <div class="grid grid-cols-1 gap-6 mt-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                        @foreach ($product_types as $type)
                             <div class="w-full max-w-sm mx-auto overflow-hidden rounded-md shadow-md">
                                <div class="flex items-end justify-end w-full bg-cover"></div>
                                <div class="px-5 py-3">
                                <h4 class="text-gray-700 uppercase">{{ $type->productTypeName }}</h4><br>
                                <h6 class="text-gray-500"><strong>Category : </strong>{{ Helper::get_CategoryName($type->catagory_id) }}</h6><br>
                                <span class="mt-2 text-gray-500"> <strong>Description : </strong>{{ $type->description }}</span><br>
                                {{-- <span class="mt-2 text-gray-500"> <strong> Product Type Catagory: </strong><br>{{ Helper::get_CategoryName($type->catagory_id)}} </span><br> --}}
                                <br><br>
                                <a href="{{url('admin/edit/productType',$type->id)}}">
                                  <button class="btn btn-outline-success">
                                    {{ __('Edit Product Type') }}
                                  </button>
                                </a>
                                  <br> <br>

                                <a href="{{url('admin/delete/productType',$type->id)}}">
                                 <button class="btn btn-outline-danger" onclick="return confirm('Do You Want To Delete This Product Type?')">
                                    {{ __('Delete Product Type') }}
                                  </button>
                                </a>



                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
            <main>
            @include('layout.footer')
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="{{ url('js/scripts.js') }}"></script>
    <script src=" https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="{{url ('assets/demo/chart-area-demo.js')}}"></script>
    <script src="{{url ('assets/demo/chart-bar-demo.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="{{url ('js/datatables-simple-demo.js') }}"></script>
    <link href="{{ url('css/styles.css') }}" rel="stylesheet"/>
</body>
</html>
