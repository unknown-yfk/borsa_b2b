@include('layout.header')

<body class="sb-nav-fixed">
    @include('nav.admin_navbar')
    @include('sweetalert::alert')
    <div id="layoutSidenav">
        @include('Sidenavbar.adminSidebar')
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Add Products</h1>
                    <div class="row">
                        <div class="card mb-4">
                            <div class="card-header">
                                Add Products Here!
                            </div>
                            <div class="card-body">
                                <div class="container rounded bg-white mt-5 mb-5">
                                    <div class="row mt-2">
                                        <center>
                                            <form action="/admin/StoreProducts" method="POST"
                                                enctype="multipart/form-data">
                                        </center>
                                        @csrf
                                        <div class="mb-3">
                                            <label> Product Name</label>
                                            <input type="text" id="name" name="name"
                                                class="form-control"required>
                                        </div>

                                        <div class="mb-3">
                                            <label> Product Image</label>
                                            <input type="file" id="image" name="image"
                                                class="form-control"required>
                                        </div>

                                        <div class="mb-3"><label>Select Catagory</label>

                                            <select id="catagory" name="catagory" class="form-control" required>
                                                @foreach ($catagory as $p)
                                                    {{-- <option value=""></option> --}}
                                                    <option value="{{ $p->id }}"> {{ $p->catagoryName }}
                                                        {{-- </option> --}}
                                                @endforeach
                                            </select>
                                        </div>

                                        <div class="mb-3"><label>Select Product Type</label>
                                            <select id="productType" name="productType" class="form-control" required>
                                                <option value=""></option>
                                                @foreach ($productType as $p)
                                                    <option value="{{ $p->id }}"> {{ $p->productTypeName }}
                                                        {{-- </option> --}}
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label>Quantity</label>
                                            <input type="number" id="Qty" min="0" name="Qty" class="form-control" required>
                                        </div>

                                        <div class="mb-3">
                                            <label> Price</label>
                                            <input type="number" id="price" name="price"
                                                pattern="[0-9]+([\.,][0-9]+)?" step="0.01" min="0"
                                                class="form-control"required>
                                        </div>
                                        <div class="mb-3">
                                            <label>Pack-Size</label>
                                            <input id="packsize" name="packsize" class="form-control">
                                        </div>

                                        <div class="mb-3">
                                            <label> Description</label>
                                            <textarea id="description" name="description" rows="5" class="form-control"></textarea>
                                        </div>
                                        <div class="mb-3"><label>Select Key Distrbutor</label>
                                            <select id="Kd_id" name="Kd_id" class="form-control" required>
                                                <option value=""></option>
                                                @foreach ($key_distro as $kd)
                                                    <option value="{{ $kd->id }}"> {{ $kd->firstName }}
                                                        {{ $kd->middleName }} {{ $kd->lastName }}
                                                        </option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <button type="submit" class="btn btn-outline-success">Save Product</button>

                                        </div>
                                    </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
            </main>
            @include('layout.footer')
        </div>
    </div>
</body>

</html>
