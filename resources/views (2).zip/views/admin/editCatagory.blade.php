@include('layout.header')
<body class="sb-nav-fixed">
    @include('nav.admin_navbar')
        @include('sweetalert::alert')
        <div id="layoutSidenav">
            @include('Sidenavbar.adminSidebar')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Edit Catagory</h1>
                        <div class="row">
                        <div class="card mb-4">
                            <div class="card-header">
                               You Can Edit The Catagory Here!
                            </div>
                            <div class="card-body">
                            <div class="container rounded bg-white mt-5 mb-5">
                                <div class="row mt-2">
                                    <center>
                        <form action="{{url('/admin/editedcatagoryStore',$product_catagories->id)}}" method= "POST" enctype="multipart/form-data"></center>
                    @csrf
                    <div class="mb-3">
                     <label> Catagory Name</label>
                       <input type="text" id="catagoryName" name="catagoryName" value="{{ $product_catagories->catagoryName }}" class="form-control">
                    </div>

                    <div class="mb-3">
                     <label> Catagory Image</label>
                     <img src="../../../assets/catagory_img/{{$product_catagories->image}}" class="rounded float-start" alt="Product Catagory Image" width="100rem" height="100rem">
                       <input type="file" id="image"  name="image" class="form-control">
                       <input type="hidden" id="old_image"  name="old_image" value="{{$product_catagories->image}}">
                    </div>

                    <div class="mb-3">
                     <label> Description</label>
                    <input type="text"  id="description" name="description" value="{{ $product_catagories->description }}"rows="5" class="form-control">
                    </div>

                    <div class="col-md-6">
                        <input type="submit" class="btn btn-outline-success" value="Update Catagory">

                     </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</main>
@include('layout.footer')
</div>
</div>
</body>
</html>
