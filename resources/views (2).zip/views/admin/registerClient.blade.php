@include('admin.header')
<body class="sb-nav-fixed">
    @include('nav.admin_navbar')
    @include('sweetalert::alert')
    <div id="layoutSidenav">
        @include('Sidenavbar.adminSidebar')
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Client Registeration</h1>
                    <div class="row">
                        <div class="card mb-4">
                            <div class="card-header">
                                Fill the form and click submit to complete Client Registeration
                            </div>
                            <div class="card-body">
                                <div class="container rounded bg-white mt-5 mb-5">
                                    <div class="row mt-2">
                                        <center>
                                            <form action="/admin/create/posts" method="POST"
                                                enctype="multipart/form-data">
                                        </center>
                                        @csrf
                                        <div class="col-md-6"><label class="labels"><strong>First Name </strong></label>
                                            <input type="text"
                                                class="form-control  @error('firstName') is-invalid @enderror"
                                                id="firstName" name="firstName" required>
                                            @error('firstName')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Middle Name</strong>
                                            </label>
                                            <input type="text" class="form-control  @error('middleName') is-invalid @enderror"
                                                id="middleName" name="middleName" required>
                                        </div>
                                        @error('middleName')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                        <div class="col-md-6"><label class="labels"><strong>Last Name</strong> </label>
                                            <input type="text"
                                                class="form-control  @error('lastName') is-invalid @enderror"
                                                id="lastName" name="lastName" required>
                                            @error('lastName')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <input type="hidden" value="client" name="userType">
                                        <div class="col-md-6"><label class="labels"><strong>User Name </strong></label>
                                            <input type="text"
                                                class="form-control  @error('userName') is-invalid @enderror"
                                                id="userName" name="userName" required>
                                            @error('userName')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong> QR
                                                    Password</strong></label>
                                            <input type="text"
                                                class="form-control  @error('QRPassword') is-invalid @enderror"
                                                id="QRPassword" name="QRPassword" required>
                                            @error('QRPassword')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Password</strong></label>
                                            <input type="password"
                                                class="form-control  @error('password') is-invalid @enderror"
                                                value="" placeholder="*********" id="password" minlength="6"
                                                name="password" required>
                                            @error('password')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"> <strong>Pin Code</strong></label>
                                            <input type="password"
                                                class="form-control  @error('pinCode') is-invalid @enderror" placeholder="****" minlength="4"
                                                id="pinCode" name="pinCode" required>
                                            @error('pinCode')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="col-md-6"> <label
                                                class="labels @error('address') is-invalid @enderror"> <strong>Address
                                                </strong></label>
                                            <input type="text" class="form-control floating" name="address"
                                                id="pac-input" tabindex="10"required>
                                            @error('address')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                            <div id="map">
                                            </div>
                                            <div id="infowindow-content">
                                                <span id="place-name" class="title"></span><br />
                                                <span id="place-address"></span>
                                            </div>
                                            <input name="lng" id="pac-role" type="hidden">
                                            <input name="lat" id="pac-lan" type="hidden">
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Mobile</strong></label>
                                            <input type="text"
                                                class="form-control  @error('mobile') is-invalid @enderror"
                                                id="mobile" name="mobile">
                                            @error('mobile')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Business Name</strong>
                                            </label>
                                            <input type="text"
                                                class="form-control  @error('businessName') is-invalid @enderror"
                                                id="businessName" name="businessName">
                                                 @error('businessName')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Business
                                                    Type</strong></label>
                                            <select id="businessType" name="businessType" class="form-control @error('businessType') is-invalid @enderror">
                                                <option value=""></option>
                                                @foreach ($businessType as $businessType)
                                                    <option value="{{ $businessType->businessName }}"> {{ $businessType->businessName }}</option>
                                                @endforeach
                                            </select>
                                            @error('businessType')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>ID Type</strong></label>
                                            <select id="idType" name="idType"
                                                class="form-control @error('idType') is-invalid @enderror">
                                                <option value=""></option>
                                                @foreach ($idType as $idType)
                                                    <option value="{{ $idType->idTypeName }}">
                                                        {{ $idType->idTypeName }}</option>
                                                @endforeach
                                            </select>
                                            @error('idType')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>ID</strong></label>
                                            <input type="file" class="form-control @error('id_path') is-invalid @enderror"
                                                id="id_path" name="id_path">
                                            @error('id_path')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Business Registeration
                                                </strong></label>
                                            <input type="text" class="form-control  @error('businessRegisteration') is-invalid @enderror" id="businessRegisteration"
                                                name="businessRegisteration">
                                            @error('businessRegisteration')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>When was Your Buisness
                                                    established </strong></label>
                                            <input type="text"
                                                class="form-control  @error('businessEstablishmentYear') is-invalid @enderror"
                                                value="" placeholder="eg: 2002" id="businessEstablishmentYear"
                                                name="businessEstablishmentYear">
                                            @error('businessEstablishmentYear')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Key
                                                    Distributor</strong></label>
                                            <select id="kd" name="kd"
                                                class="form-control  @error('kd') is-invalid @enderror" required>
                                                <option value=""></option>
                                                @foreach ($key_distro as $kd)
                                                    <option value="{{ $kd->user_id }}"> {{ $kd->firstName }}
                                                        {{ $kd->middleName }} {{ $kd->lastName }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('kd')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="col-md-12"><label class="labels"><strong>Status</strong></label>
                                            <div class="col-md-6">
                                                <select id="status" name="status"
                                                    class="form form-control  @error('status') is-invalid @enderror"
                                                    required>
                                                    <option value=""></option>
                                                    <option value="active">Active</option>
                                                    <option value="inactive">Inactive</option>
                                                </select>
                                                @error('status')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <br>
                                        <input type="submit" class="form form-control btn btn-outline-success mt-5"
                                            value="Submit">
                                        <input type="reset" class="form form-control btn btn-outline-danger mt-2"
                                            value="Clear">
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
            </main>
            @include('layout.footer')
        </div>
    </div>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA6FjTNtaiuf3PGaAVvVFHYgc6M_tdM24k&callback=initMap&libraries=places&v=weekly"
      async></script>
<script>
      function initMap() {
         const map = new google.maps.Map(document.getElementById("map"), {
           center: { lat: 40.749933, lng: -73.98633 },
           zoom: 13,
           mapTypeControl: false,
         });
         const card = document.getElementById("pac-card");
         const input = document.getElementById("pac-input");
         const input1 = document.getElementById("pac-role");
         const biasInputElement = document.getElementById("use-location-bias");
         const strictBoundsInputElement = document.getElementById("use-strict-bounds");

         const options = {
           fields: ["formatted_address", "geometry", "name"],
           strictBounds: false,
           types: ["establishment"],
         };

         map.controls[google.maps.ControlPosition.TOP_LEFT].push(card);

         const autocomplete = new google.maps.places.Autocomplete(input, options);

         autocomplete.bindTo("bounds", map);

         const infowindow = new google.maps.InfoWindow();
         const infowindowContent = document.getElementById("infowindow-content");

         infowindow.setContent(infowindowContent);

         const marker = new google.maps.Marker({
           map,
           anchorPoint: new google.maps.Point(0, -29),
         });

         autocomplete.addListener("place_changed", () => {
           infowindow.close();
           marker.setVisible(false);

           const place = autocomplete.getPlace();

           if (!place.geometry || !place.geometry.location) {

             window.alert("No details available for input: '" + place.name + "'");
             return;
           }

           // If the place has a geometry, then present it on a map.
           if (place.geometry.viewport) {
             map.fitBounds(place.geometry.viewport);
           } else {
             map.setCenter(place.geometry.location);
             map.setZoom(17);
           }
            $('#pac-role').val(place.geometry.location.lng());
            $('#pac-lan').val(place.geometry.location.lat());

           marker.setPosition(place.geometry.location);
           marker.setVisible(true);
           infowindowContent.children["place-name"].textContent = place.name;
           infowindowContent.children["place-address"].textContent =
             place.formatted_address;
           infowindow.open(map, marker);
         });



       }
</script>
</body>
</html>
