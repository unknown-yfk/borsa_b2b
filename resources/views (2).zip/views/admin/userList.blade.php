@include('layout.header')
<body class="sb-nav-fixed">
    @include('nav.admin_navbar')
        <div id="layoutSidenav">
            @include('Sidenavbar.adminSidebar')
            <div id="layoutSidenav_content">
                <main>
                   <div class="container-fluid px-4">
                        <h1 class="mt-4">User List</h1>
                        <div class="row">
                        <div class="card mb-4">
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>User ID</th>
                                            <th>Full Name</th>
                                            <th>User Name</th>
                                            <th>User Type</th>
                                            <th>Account Status</th>
                                            <th>Change Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                      @foreach($userList as $user)
                                        <tr>
                                        <td>{{$user->id}}</td>
                                        <td>{{$user->firstName}} {{$user->middleName}} {{$user->lastName}}</td>
                                        <td>{{$user->userName}}</td>
                                        <td>{{$user->userType}}</td>
                                        <td>{{$user->status}}</td>
                                        <td>
                                        <form action="{{url('/admin/user/activate',$user->id)}}" method="POST">
                                            @csrf
                                            <input type="submit" class="btn btn-success" value="  Active  ">
                                        </form>
                                        <form class="mt-2" action="/admin/user/deactivate/{{$user->id}}" method="POST">
                                            @csrf
                                            <input type="hidden" value="inactive" name="deactivate">
                                            <input type="submit" class="btn btn-danger" value="Deactive">
                                        </form>
                                        </td>
                                        </tr>
                                        @endforeach
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            @include('layout.footer')
        </div>
    </div>
</body>
</html>
