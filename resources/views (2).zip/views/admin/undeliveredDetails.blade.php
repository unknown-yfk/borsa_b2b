@include('layout.header')
<body class="sb-nav-fixed">
    @include('sweetalert::alert')
    @include('nav.admin_navbar')
        @include('sweetalert::alert')
        <div id="layoutSidenav">
            @include('Sidenavbar.adminSidebar')
            <div id="layoutSidenav_content">
                <main>
              <div class="container-fluid px-4">
                        <h1 class="mt-4">Undilverd OrderedProducts</h1>
                        <div class="row">
                        <div class="card mb-4">
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                        <!-- Set columns width -->
                                        <th class="text-center py-3 px-4" style="min-width: 400px;">Product Name &amp; Details</th>
                                        <th class="text-center py-3 px-4" style="width: 120px;">Undelivered Quantity</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($deliveredProducts as $item)
                                        @if($item->undelivered_quantity>0)
                                          <tr>
                                            <td class="p-4">
                                              <div class="media align-items-center">
                                                <img src="" class="d-block ui-w-40 ui-bordered mr-4" alt="">
                                                <div class="media-body">
                                                  <a href="#" class="d-block text-dark">{{$item->name}}</a>
                                                  <small>
                                                    <span class="text-muted"><strong> Description:</strong></span> {{$item->description}}
                                                  </small>
                                                </div>
                                              </div>
                                            </td>
                                            <td class="align-middle p-4"><input type="number" class="form-control text-center" value="{{$item->undelivered_quantity}}" readonly></td>
                                        </tr>
                                         @endif
                                         @endforeach
                                        </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                    @include('layout.footer')
                </div>
            </div>
        </body>
    </html>
