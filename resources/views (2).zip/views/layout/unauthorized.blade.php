{{Auth::logout()}}
