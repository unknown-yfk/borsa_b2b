@include('RSP.header')
<body class="sb-nav-fixed" onload="getLocation()">
    @include('nav.rsp_navbar')
    <div id="layoutSidenav">
        @include('Sidenavbar.rspSidebar')
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Profile Setup</h1>
                    <div class="row">
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                Fill the Form and Click Submit to Complete Profile Setup.
                            </div>
                            <div class="card-body">
                                <div class="container rounded bg-white mt-5 mb-5">
                                    <div class="row mt-2">
                                        <center>
                                            <form action="/rsp/create/posts" method="POST"
                                                enctype="multipart/form-data">
                                        </center>
                                        @csrf
                                        <div class="col-md-6">
                                            <label class="labels">User Photo</label>
                                            <input type="file"
                                                class="form-control @error('profilePicture') is-invalid @enderror"
                                                id="profilePicture" name="profilePicture">
                                            @error('profilePicture')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"> <label class="labels"><strong>Home Address</strong></label>
                                            <input type="text"
                                                class="form-control floating form-control @error('address') is-invalid @enderror"
                                                    name="address" id="homeAddress"
                                                tabindex="10"required>
                                            <div id="map">
                                            </div>
                                            <div id="infowindow-content">
                                                <span id="place-name" class="title"></span><br />
                                                <span id="place-address"></span>
                                            </div>
                                         <input name="lng" id="pac-role" type="hidden">
                                         <input name="lat" id="pac-lan" type="hidden">
                                            @error('address')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Mobile</strong></label>
                                            <input type="text"
                                                class="form-control @error('mobile') is-invalid @enderror"
                                                id="mobile" name="mobile"required>
                                            @error('mobile')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="col-md-6"><label class="labels"><strong>Your Goverment
                                                    ID</strong></label>
                                            <input type="file"
                                                class="form-control @error('id_path') is-invalid @enderror"
                                                placeholder="" id="id_path" name="id_path"required>
                                            @error('id_path')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>ID type</strong></label>
                                            <select id="idType" name="idType"
                                                class="form-control @error('idType') is-invalid @enderror"required>
                                                <option value=""></option>
                                                @foreach ($idType as $idType)
                                                    <option value="{{ $idType->idTypeName }}">{{ $idType->idTypeName }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('idType')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>ID number</strong> </label>
                                            <input type="text"
                                                class="form-control @error('ID_number') is-invalid @enderror" id="ID_number"
                                                name="ID_number"required>
                                            @error('ID_number')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>ID Issue Date
                                                </strong></label>
                                            <input type="date"
                                                class="form-control @error('ID_issue_date') is-invalid @enderror" id="ID_issue_date"
                                                name="ID_issue_date"required>
                                            @error('ID_issue_date')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>ID Expiry Date
                                                </strong></label>
                                            <input type="date"
                                                class="form-control @error('ID_expiry_date') is-invalid @enderror" id = "ID_expiry_date"
                                                name="ID_expiry_date"required>
                                            @error('ID_expiry_date')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <input type="submit" class="form form-control btn btn-outline-success mt-5"
                                            value="Submit">
                                        <input type="reset" class="form form-control btn btn-outline-danger mt-2"
                                            value="Clear">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
            </main>
            @include('layout.footer')
        </div>
    </div>
<script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA6FjTNtaiuf3PGaAVvVFHYgc6M_tdM24k&callback=initMap&libraries=places&v=weekly"
      async></script>
   <script>
      function initMap() {
         const map = new google.maps.Map(document.getElementById("map"), {
           center: { lat: 40.749933, lng: -73.98633 },
           zoom: 13,
           mapTypeControl: false,
         });
         const card = document.getElementById("pac-card");
         const input = document.getElementById("pac-input");
         const input1 = document.getElementById("pac-role");
         const biasInputElement = document.getElementById("use-location-bias");
         const strictBoundsInputElement = document.getElementById("use-strict-bounds");

         const options = {
           fields: ["formatted_address", "geometry", "name"],
           strictBounds: false,
           types: ["establishment"],
         };

         map.controls[google.maps.ControlPosition.TOP_LEFT].push(card);

         const autocomplete = new google.maps.places.Autocomplete(input, options);

         autocomplete.bindTo("bounds", map);

         const infowindow = new google.maps.InfoWindow();
         const infowindowContent = document.getElementById("infowindow-content");

         infowindow.setContent(infowindowContent);

         const marker = new google.maps.Marker({
           map,
           anchorPoint: new google.maps.Point(0, -29),
         });

         autocomplete.addListener("place_changed", () => {
           infowindow.close();
           marker.setVisible(false);

           const place = autocomplete.getPlace();

           if (!place.geometry || !place.geometry.location) {

             window.alert("No details available for input: '" + place.name + "'");
             return;
           }

           // If the place has a geometry, then present it on a map.
           if (place.geometry.viewport) {
             map.fitBounds(place.geometry.viewport);
           } else {
             map.setCenter(place.geometry.location);
             map.setZoom(17);
           }
            $('#pac-role').val(place.geometry.location.lng());
            $('#pac-lan').val(place.geometry.location.lat());

           marker.setPosition(place.geometry.location);
           marker.setVisible(true);
           infowindowContent.children["place-name"].textContent = place.name;
           infowindowContent.children["place-address"].textContent =
             place.formatted_address;
           infowindow.open(map, marker);
         });



       }
</script>
</body>

</html>
