<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>e-pace</title>
    <link href="{{ url('css/styles.css') }}" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA6FjTNtaiuf3PGaAVvVFHYgc6M_tdM24k&callback=initMap&libraries=places&v=weekly"
        async></script>
    <script>
        function initMap() {
            const map = new google.maps.Map(document.getElementById("map"), {
                center: {
                    lat: 40.749933,
                    lng: -73.98633
                },
                zoom: 13,
                mapTypeControl: false,
            });
            const card = document.getElementById("pac-card");
            const input = document.getElementById("pac-input");
            const input1 = document.getElementById("pac-role");
            const biasInputElement = document.getElementById("use-location-bias");
            const strictBoundsInputElement = document.getElementById("use-strict-bounds");

            const options = {
                fields: ["formatted_address", "geometry", "name"],
                strictBounds: false,
                types: ["establishment"],
            };

            map.controls[google.maps.ControlPosition.TOP_LEFT].push(card);

            const autocomplete = new google.maps.places.Autocomplete(input, options);

            autocomplete.bindTo("bounds", map);

            const infowindow = new google.maps.InfoWindow();
            const infowindowContent = document.getElementById("infowindow-content");

            infowindow.setContent(infowindowContent);

            const marker = new google.maps.Marker({
                map,
                anchorPoint: new google.maps.Point(0, -29),
            });

            autocomplete.addListener("place_changed", () => {
                infowindow.close();
                marker.setVisible(false);

                const place = autocomplete.getPlace();

                if (!place.geometry || !place.geometry.location) {

                    window.alert("No details available for input: '" + place.name + "'");
                    return;
                }

                // If the place has a geometry, then present it on a map.
                if (place.geometry.viewport) {
                    map.fitBounds(place.geometry.viewport);
                } else {
                    map.setCenter(place.geometry.location);
                    map.setZoom(17);
                }
                $('#pac-role').val(place.geometry.location.lng());
                $('#pac-lan').val(place.geometry.location.lat());

                marker.setPosition(place.geometry.location);
                marker.setVisible(true);
                infowindowContent.children["place-name"].textContent = place.name;
                infowindowContent.children["place-address"].textContent =
                    place.formatted_address;
                infowindow.open(map, marker);
            });
        }
    </script>
</head>

<body class="sb-nav-fixed">
    @include('nav.rsp_navbar')
    <div id="layoutSidenav">
        @include('Sidenavbar.rspSidebar')
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Profile Update</h1>
                    <div class="row">
                        <div class="card mb-4">
                            <div class="card-header">
                                Update!
                            </div>
                            <div class="card-body">
                                <div class="container rounded bg-white mt-5 mb-5">
                                    <div class="row mt-2">
                                        <center>
                                            <form action="/rsp/update/edits" method="POST"
                                                enctype="multipart/form-data">
                                        </center>
                                        @foreach ($rspProfile as $profile)
                                            @csrf
                                            @method('PUT')
                                            <div class="col-md-12">
                                                <img src="../../assets/users_img/{{ Auth::user()->userPhoto }}"
                                                    class="rounded float-start" alt="{{ Auth::user()->userName }}"
                                                    width="200rem" height="200rem">
                                                <input type="file"
                                                    class="form-control @error('userPhoto') is-invalid @enderror"
                                                    id="userPhoto" name="userPhoto">
                                                <input type="hidden" value="{{ Auth::user()->userPhoto }}"
                                                    id="userPhoto_recover" name="userPhoto_recover">
                                                @error('userPhoto')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-6 mt-6"><label class="labels"><strong> First
                                                    Name</strong></label>
                                            <input type="text"
                                                class="form-control  @error('firstName') is-invalid @enderror"
                                                id="firstName" name="firstName" value="{{ $profile->firstName }}"
                                                required>
                                            @error('firstName')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Middle Name</strong></label>
                                            <input type="text"
                                                class="form-control @error('middleName') is-invalid @enderror"
                                                id="middleName" name="middleName"
                                                value="{{ $profile->middleName }}"required>
                                            @error('middleName')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Last Name</strong></label>
                                            <input type="text"
                                                class="form-control   @error('lastName') is-invalid @enderror"
                                                id="lastName" name="lastName" value="{{ $profile->lastName }}"required>
                                            @error('lastName')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>User Name</strong></label>
                                            <input type="text"
                                                class="form-control   @error('userName') is-invalid @enderror"
                                                id="userName" name="userName"
                                                value="{{ $profile->userName }}"required>
                                            @error('userName')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>E-mail</strong></label>
                                            <input type="email"
                                                class="form-control   @error('email') is-invalid @enderror"
                                                id="email" name="email" value="{{ $profile->email }}"required>
                                            @error('email')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                          <div class="col-md-6"> <label class="labels"><strong>Address</strong> </label>
                                                <input type="text" class="form-control floating form-control @error('address') is-invalid @enderror" name="address"
                                                    id="pac-input" tabindex="10"value="{{ $profile->address }}">
                                                <div id="map">
                                                </div>
                                                <div id="infowindow-content">
                                                    <span id="place-name" class="title"></span><br />
                                                    <span id="place-address"></span>
                                                </div>
                                                <input name="lng" id="pac-role" type="hidden" value="{{$profile->longtude}}">
                                                <input name="lat" id="pac-lan" type="hidden" value="{{$profile->latitude}}">
                                                 @error('address')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                            </div>
                                        <div class="col-md-6"><label class="labels"><strong>Mobile</strong></label>
                                            <input type="text"
                                                class="form-control   @error('mobile') is-invalid @enderror"
                                                id="mobile" name="mobile"
                                                value="{{ $profile->mobile }}"required>
                                            @error('mobile')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-12"><label class="labels"><strong>Your ID</strong></label>
                                            <img src="../../assets/gov_img/{{ $profile->id_filepath }}"
                                                class="rounded float-start" alt="{{ $profile->id_file_path }}"
                                                width="200rem" height="200rem">
                                            <input type="file"
                                                class="form-control  @error('id_path') is-invalid @enderror"
                                                id="id_path" name="id_path">
                                            <input type="hidden" name="id_path_recover"
                                                value="{{ $profile->id_filepath }}">
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-6"><label class="labels"><strong>ID type</strong></label>
                                            <select id="idType" name="idType"
                                                class="form-control @error('idType') is-invalid @enderror" required>
                                                <option value=""></option>
                                                @foreach ($idType as $idType)
                                                    <option value="{{ $idType->idTypeName }}" {{ $profile->ID_type === $idType->idTypeName ? 'selected' : '' }}> {{ $idType->idTypeName }}</option>
                                                @endforeach
                                            </select>
                                            @error('idType')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror

                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>ID Number</strong></label>
                                            <input type="text"
                                                class="form-control  @error('ID_number') is-invalid @enderror"
                                                value="{{ $profile->ID_number }}" id="ID_number"
                                                name="ID_number"required>
                                            @error('ID_number')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>ID Issue Date
                                                </strong></label>
                                            <input type="date"
                                                class="form-control  @error('ID_issue_date') is-invalid @enderror"
                                                value={{ $profile->ID_issue_date }} name="ID_issue_date"required>
                                            @error('ID_issue_date')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>ID Expiry Date
                                                </strong></label>
                                            <input type="date"
                                                class="form-control  @error('ID_expiry_date') is-invalid @enderror"
                                                value={{ $profile->ID_expiry_date }} id="ID_expiry_date"
                                                name="ID_expiry_date" required>
                                            @error('ID_expiry_date')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <br>
                                        <br><br>
                                        <input type="submit" class="form-control btn btn-outline-success mt-4"
                                            value="Submit">
                                        @endforeach
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
            </main>
            @include('layout.footer')
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>
    <script src="{{ url('js/scripts.js') }}"></script>
    <script src=" https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="{{ url('assets/demo/chart-area-demo.js') }}"></script>
    <script src="{{ url('assets/demo/chart-bar-demo.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="{{ url('js/datatables-simple-demo.js') }}"></script>
</body>

</html>
