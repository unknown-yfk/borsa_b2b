@include('layout.header')
 <body class="sb-nav-fixed">
    @include('sweetalert::alert')
    @include('nav.agent_navbar')
        <div id="layoutSidenav">
            @include('Sidenavbar.agentSidebar')
                <div id="layoutSidenav_content">
                    <main>
                        <div class="container-fluid px-4">
                            <h1 class="mt-4">Your Orders</h1>
                            <div class="row">
                            <div class="card-body">
                            <div class="card mb-4">
                            <div class="card-header">
                                <strong>Order History</strong>
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Client</th>
                                            <th>Key Distributor</th>
                                            <th>Order Date</th>
                                            <th>Delivery Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                      @foreach($client as $order)
                                      <tr>
                                            <td>{{$order->id}}</td>
                                            <td>{{$order->firstName}} {{$order->middleName}} {{$order->lastName}}</td>
                                            <td>{{Helper::get_kd_name($order->KD_id)}}</td>
                                            <td>{{$order->createdDate}}</td>
                                            <td>{{$order->deliveryStatus}}</td>
                                            <td><form action="{{ ('/order/details') }}" method="POST">
                                               @csrf
                                               <input type="hidden" value="{{$order->id}}" name="order_id" >
                                             <button type="submit" class="btn btn-outline-success" >View Details</button>
                                              </form></td>
                                        </tr>
                                @endforeach
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                </main>
            @include('layout.footer')
            </div>
        </div>
   </body>
</html>
