@include('agent.header')

<body class="sb-nav-fixed">
    @include('nav.agent_navbar')
    <div id="layoutSidenav">
        @include('Sidenavbar.agentSidebar')
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">My Profile</h1>
                    <div class="row">
                        <div class="card mb-4">
                            <div class="card-body">
                                <div class="container rounded bg-white mt-5 mb-5">
                                    <div class="row mt-2">
                                        @foreach ($agentProfile as $profile)
                                            <div class="col-md-6">
                                                <img src="../../assets/users_img/{{ Auth::user()->userPhoto }}"
                                                    class="rounded-circle shadow-4-strong"
                                                    alt="{{ Auth::user()->userName }}" width="100rem" height="100rem">

                                            </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-6"><label class="labels"><strong> First Name</strong></label>
                                            <p class="form-control">{{ $profile->firstName }}</p>
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Middle Name</strong></label>
                                            <p class="form-control">{{ $profile->middleName }}</p>
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Last Name</strong></label>
                                            <p class="form-control">{{ $profile->lastName }}</p>
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>User Name</strong></label>
                                            <p class="form-control">{{ $profile->userName }}</p>
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Email</strong></label>
                                            <p class="form-control">{{ $profile->email }}</p>
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Resident
                                                    Address</strong></label>
                                            <p class="form-control">{{ $profile->address }}</p>
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Phone
                                                    Number</strong></label>
                                            <p class="form-control">{{ $profile->mobile }}</p>
                                        </div>

                                        <div class="col-md-12">
                                            <label class="labels"><strong>Goverment ID</strong></label>
                                            <img src="../../assets/gov_img/{{ $profile->id_file_path }}"
                                                class="rounded float-start" alt="{{ $profile->id_file_path }}"
                                                width="100rem" height="100rem">

                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>ID type</strong></label>
                                            <p class="form-control">{{ $profile->ID_type }}</p>
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>ID number</strong></label>
                                            <p class="form-control">{{ $profile->ID_number }}</p>
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>ID issue
                                                    date</strong></label>
                                            <p class="form-control">{{ $profile->ID_issue_date->format('y-m-d') }}</p>
                                        </div>




                                        <div class="col-md-6"><label class="labels"><strong>ID expiry
                                                    date</strong></label>
                                            <p class="form-control">{{ $profile->ID_expiry_date->format('y-m-d') }}</p>
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Business
                                                    Name</strong></label>
                                            <p class="form-control">{{ $profile->businessName }}</p>
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Buisness
                                                    Type</strong></label>
                                            <p class="form-control">{{ $profile->businessType }}</p>
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Busienss
                                                    Address</strong></label>
                                            <p class="form-control">{{ $profile->businessAddress }}</p>
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Buisness Licence
                                                    Number</strong></label>
                                            <p class="form-control">{{ $profile->licenceNumber }}</p>
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>issue date</strong></label>
                                            <p class="form-control">{{ $profile->issueDate }}</p>
                                        </div>

                                        <div class="col-md-12">
                                            <label class="labels"><strong>Buisness Licence</strong></label>
                                            <img src="../../assets/licences_img/{{ $profile->licenceFilePath }}"
                                                class="rounded float-start" alt="{{ Auth::user()->userName }}"
                                                width="100rem" height="100rem">

                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>expiry date</strong></label>
                                            <p class="form-control">{{ $profile->expiryDate }}</p>
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Tin Number</strong></label>
                                            <p class="form-control">{{ $profile->tinNumber }}</p>
                                        </div>
                                        <div class="col-md-6"><label class="labels"><strong>Business establishment
                                                    year</strong></label>
                                            <p class="form-control">{{ $profile->businessEstablishmentYear }}</p>
                                        </div>
                                        @endforeach
                                    </div>
                                    <div class="row mt-2">
                                        <center><a href="/agent/update/edit"><button
                                                    class="btn btn-primary">Update</button></a></center>
                                    </div>
                                </div>
                            </div>
                        </div>
            </main>
            @include('layout.footer')
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>
    <script src="{{ url('js/scripts.js') }}"></script>
    <script src=" https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="{{ url('assets/demo/chart-area-demo.js') }}"></script>
    <script src="{{ url('assets/demo/chart-bar-demo.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="{{ url('js/datatables-simple-demo.js') }}"></script>
</body>

</html>
