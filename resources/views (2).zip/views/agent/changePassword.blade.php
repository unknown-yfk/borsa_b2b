@include('agent.header')

<body class="sb-nav-fixed">
    @include('nav.agent_navbar')
    <div id="layoutSidenav">
        @include('Sidenavbar.agentSidebar')
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Change Password</h1>
                    <div class="row">
                        <div class="card-body">
                            <div class="card mb-4">
                                <div class="container rounded bg-white mt-5 mb-5">
                                    <div class="row mt-2">
                                        <form method="POST" action="/agent/password/change/post">
                                            {{ csrf_field() }}
                                            <div class="card card-bordered card-preview">
                                                <div class="card-header">
                                                    <h4 class="card-title">Change Password</h4>
                                                </div>
                                                <div class="card-body">
                                                    <div class="row gy-4">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label for="current_password"
                                                                    class="control-label">Current Password</label>
                                                                <input type="password" name="current_password"
                                                                    id="current_password" value=""
                                                                    class="form-control @error('current_password') is-invalid @enderror"
                                                                    required autocomplete="off">
                                                                @error('current_password')
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong>{{ $message }}</strong>
                                                                    </span>
                                                                @enderror
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row gy-4">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="password"
                                                                    class="control-label">Password</label>
                                                                <input type="password" name="password" id="password"
                                                                    class="form-control @error('password') is-invalid @enderror"
                                                                    required autocomplete="off">
                                                                @error('password')
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong>{{ $message }}</strong>
                                                                    </span>
                                                                @enderror
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="password_confirmation"
                                                                    class="control-label">Conforim Password</label>
                                                                <input type="password" name="password_confirmation"
                                                                    id="password_confirmation"
                                                                    class="form-control @error('password_confirmation') is-invalid @enderror"
                                                                    required autocomplete="off">
                                                                @error('password_confirmation')
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong>{{ $message }}</strong>
                                                                    </span>
                                                                @enderror
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-footer border-top ">
                                                    <button type="submit"
                                                        class="btn btn-primary  float-right">Save</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
            </main>
            @include('layout.footer')
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>
    <script src="{{ url('js/scripts.js') }}"></script>
    <script src=" https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="{{ url('assets/demo/chart-area-demo.js') }}"></script>
    <script src="{{ url('assets/demo/chart-bar-demo.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="{{ url('js/datatables-simple-demo.js') }}"></script>
</body>

</html>
