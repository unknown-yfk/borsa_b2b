@include('dashboard.header')
<body class="sb-nav-fixed">
    @include('nav.agent_navbar')
        @include('sweetalert::alert')
        <div id="layoutSidenav">
            @include('Sidenavbar.agentSidebar')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">{{ Auth::user()->firstName }} {{ Auth::user()->middleName }}</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                        @if (auth()->user()->agent == Null)
                        <div class="card-body border-top">
            <div class="alert alert-danger" role="alert">
              <h4 class="alert-heading">Well done!</h4>
              <p>

              </p>
              <hr />
              <p class="mb-0">
                Please complete your profile set-up to use the system! <a href="/agent/create/post">Click here</a> to do so.
              </p>
            </div>
            @endif
                        <div class="row">
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-primary text-white mb-4">
                                    <div class="card-body">Confirmed Orders</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                       <h1 class="small text-white stretched-link">{{$confirm}}</h1>

                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-warning text-white mb-4">
                                    <div class="card-body">Unconfirmed Orders</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <h1 class="small text-white stretched-link">{{$unconfirm}}</h1>
                                         </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-success text-white mb-4">
                                    <div class="card-body">Delivered Orders</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <h1 class="small text-white stretched-link">{{$delieverd}}</h1>
                                       </div>
                                </div>
                            </div>
                </div>
                <div class="row">
                <!-- column -->
                <div class="col-lg-6">

                    <!-- card new -->
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <h4 class="card-title mb-0">New Notifications</h4>
                                <div class="tetx-right">
                                    <a href="/markAsRead" type="button"
                                        class="btn btn-success badge rounded-pill btn-sm text-white">
                                        Mark As Read
                                    </a>
                                </div>
                            </div>
                        </div>
                        <ul class="list-style-none">

                                    <li class="d-flex no-block card-body border-top">
                                        <i class="mdi mdi-check-circle fs-4 w-30px mt-1"></i>
                                        <div>
                                            <a href="#"
                                                class="mb-0 font-medium p-0"></a>
                                            <span class="text-muted"></span>
                                        </div>
                                    </li>

                        </ul>
                    </div>
                </div>
            </div><br>
                </main>
                @include('layout.footer')
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="{{ url('js/scripts.js') }}"></script>
        <script src=" https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="{{url ('assets/demo/chart-area-demo.js')}}"></script>
        <script src="{{url ('assets/demo/chart-bar-demo.js') }}"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="{{url ('js/datatables-simple-demo.js') }}"></script>
    </body>
</html>
